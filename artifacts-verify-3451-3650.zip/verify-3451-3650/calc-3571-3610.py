# -*- coding: utf-8 -*-
"""
阶段二核验 q3571-q3610 独立复算脚本。
方法：sympy 符号求导 + 公式归纳核对；mpmath/数值采样复核参数方程、隐函数、
反函数与高阶导等条目。只复核，不改原稿。
"""
import sympy as sp
import mpmath as mp

x, y, z, t, u, v, s, a, b, k, m, n = sp.symbols('x y z t u v s a b k m n', real=True)
results = []

def check(q, label, card_expr, calc_expr, domain_msg=""):
    """符号恒等比对；不可符号比对时返回 None，由数值采样另验。"""
    try:
        diff = sp.simplify(sp.expand(card_expr - calc_expr))
        ok = diff == 0
    except Exception as e:
        ok = None
        diff = f"EXC {e}"
    results.append((q, label, ok, str(diff), domain_msg))
    return ok

# ---------- q3571 ----------
# 书页面图：v = x^2 + y（无 y 上标）；卡题干写成 v=x^2+y^2
# 书stem 复算：z=u cos v, u=e^{xy}, v=x^2+y
u_xy = sp.exp(x*y)
v_book = x**2 + y
z_book = u_xy*sp.cos(v_book)
zx_book = sp.diff(z_book, x)
# 卡stem：v=x^2+y^2
v_card = x**2 + y**2
z_card = u_xy*sp.cos(v_card)
zx_card_stem = sp.diff(z_card, x)
# 卡答案表达式
ans_card = sp.exp(x*y)*(y*sp.cos(x**2+y**2) - 2*x*sp.sin(x**2+y**2))
check("3571", "主(书stem v=x²+y)", zx_book, sp.exp(x*y)*(y*sp.cos(x**2+y)-2*x*sp.sin(x**2+y)))
check("3571", "主(卡stem v=x²+y²)", ans_card, zx_card_stem)
# 变式 z=uv, u=e^{xy}, v=x²+y²
var3571 = sp.exp(x*y)*(y*(x**2+y**2)+2*x)
check("3571", "变式 z=uv", var3571, sp.diff(u_xy*(x**2+y**2), x))

# ---------- q3572 ----------
yy = (1+1/x)**x
check("3572", "主 y'=...", sp.simplify(sp.diff(yy, x)),
      yy*(sp.log(1+1/x)-1/(x+1)))
var3572 = (2+x)**x
check("3572", "变式 y=(2+x)^x", sp.diff(var3572, x),
      var3572*(sp.log(2+x)+x/(2+x)))

# ---------- q3573 ----------
# 验点：e^{1+0}=e != 1*0（不等式成立即点不在曲线上）
results.append(("3573", "验点 e^1 ≠ 0", sp.exp(1) != sp.S(0), f"e={sp.exp(1)} ≠ 0", "点不在曲线上"))
# e^{1+y}=y 无实解：左恒正，y<=0 时右<=0；y>0 时 e^{1+y}>e>y
sol = sp.solve(sp.exp(1+y)-y, y)
results.append(("3573", "变式 x=1 无实解", sol == [], f"solve={sol}", "e^{1+y}=y"))

# ---------- q3574 ----------
xc, yc = sp.cos(t)**3, sp.sin(t)**3
check("3574", "主 dy/dx", sp.diff(yc, t)/sp.diff(xc, t), -sp.tan(t))
# 变式 x=sin^3 t, y=cos^3 t
check("3574", "变式", sp.diff(sp.cos(t)**3, t)/sp.diff(sp.sin(t)**3, t), -sp.cot(t))

# ---------- q3575 ----------
# 可导区间内同号，|u| 去掉后按 ln u 求导（绝对值不影响导数）
yy5 = sp.log(sp.sec(x)+sp.tan(x))
check("3575", "主 y''", sp.simplify(sp.diff(yy5, x, 2)), sp.sec(x)*sp.tan(x))
# 变式 ln|tan x|  y'' = -cos2x/(sin²x cos²x)
yy5v = sp.log(sp.tan(x))
check("3575", "变式 y''", sp.simplify(sp.diff(yy5v, x, 2)),
      -sp.cos(2*x)/(sp.sin(x)**2*sp.cos(x)**2))

# ---------- q3576 ----------
# 抽象链式：dw/dx=f1'+f2'g'+f3'h'，结构核对无数值复算
results.append(("3576", "主 全导数结构", True, "f1'+f2'g'(x)+f3'h'(x)", "抽象函数，按依赖树"))
results.append(("3576", "变式 w=f(x,xy)", True, "f1'+y f2'", "y 为常数"))

# ---------- q3577 ----------
# 隐函数 x²+y²=e^{arctan(y/x)}；在曲线上取点数值比对 y'=(2x+y)/(x-2y)
# 极坐标：r²=e^θ → r=e^{θ/2}，取 θ=0 → (x,y)=(1,0)
def implicit_yprime(F, xv, yv):
    return float(-sp.diff(F, x).subs({x: xv, y: yv})/sp.diff(F, y).subs({x: xv, y: yv}))
F77 = x**2+y**2-sp.exp(sp.atan(y/x))
yp77_num = implicit_yprime(F77, 1.0, 0.0)
ans77_num = float((2*1.0+0.0)/(1.0-0.0))
results.append(("3577", "主 y' 采样(1,0)", abs(yp77_num-ans77_num) < 1e-9,
               f"隐函数导={yp77_num:.6f} 卡式={ans77_num:.6f}", "r=e^{θ/2}, θ=0"))
# 变式 x²+y²=e^{2 arctan(y/x)}
F77v = x**2+y**2-sp.exp(2*sp.atan(y/x))
yp77v_num = implicit_yprime(F77v, 1.0, 0.0)
ans77v_num = float((1.0+0.0)/(1.0-0.0))
results.append(("3577", "变式 y' 采样(1,0)", abs(yp77v_num-ans77v_num) < 1e-9,
               f"隐函数导={yp77v_num:.6f} 卡式={ans77v_num:.6f}", ""))

# ---------- q3578 ----------
yy8 = sp.asin(sp.sqrt(1-x**2))
yp8 = sp.simplify(sp.diff(yy8, x))
results.append(("3578", "主 分支", "符号含 |x|", str(yp8), "x>0: -1/√; x<0: +1/√; 0 不可导"))
# 数值采样
mp.mp.dps = 20
for xv, sign in [(0.5, -1), (-0.5, +1)]:
    num = float(mp.diff(lambda q: mp.asin(mp.sqrt(1-q*q)), xv))
    expect = float(sign/mp.sqrt(1-xv**2))
    results.append(("3578", f"采样 x={xv}", abs(num-expect) < 1e-12, f"f'={num:.6f} 期望={expect:.6f}", ""))
# 变式 arccos
yy8v = sp.acos(sp.sqrt(1-x**2))
results.append(("3578", "变式 分支", True, "x>0:+1/√, x<0:-1/√", "外层反号"))

# ---------- q3579 ----------
x9 = sp.log(1+t**2); y9 = t-sp.atan(t)
dy9 = sp.diff(y9, t)/sp.diff(x9, t)
d2y9 = sp.diff(dy9, t)/sp.diff(x9, t)
check("3579", "主 d²y/dx²", sp.simplify(d2y9), (1+t**2)/(4*t))
results.append(("3579", "主 t=1 取值", sp.simplify(d2y9.subs(t, 1)) == sp.Rational(1,2),
               f"t=1: {d2y9.subs(t,1)}", ""))
results.append(("3579", "变式 t=2", sp.simplify(d2y9.subs(t, 2)) == sp.Rational(5,8),
               f"t=2: {d2y9.subs(t,2)}", ""))

# ---------- q3580 ----------
z10 = sp.tan(3*x+2*y)
x10, y10 = t**3, 1/t
dz10 = sp.diff(z10, x)*sp.diff(x10, t) + sp.diff(z10, y)*sp.diff(y10, t)
dz10 = dz10.subs({x: x10, y: y10})
ans10 = (9*t**2-2/t**2)*sp.sec(3*t**3+2/t)**2
check("3580", "主 dz/dt", sp.simplify(dz10), sp.simplify(ans10))
# 变式 x=t²：数值 t=1 比对
x10v = t**2
dz10v = sp.diff(z10, x)*sp.diff(x10v, t) + sp.diff(z10, y)*sp.diff(y10, t)
dz10v = dz10v.subs({x: x10v, y: y10})
card10v = (6*t-2/t**2)*sp.sec(3*t**2+2/t)**2
tv = 1.0
results.append(("3580", "变式 t=1 采样",
               abs(float(dz10v.subs(t, tv))-float(card10v.subs(t, tv))) < 1e-9,
               f"链式={float(dz10v.subs(t,tv)):.6f} 卡式={float(card10v.subs(t,tv)):.6f}", ""))

# ---------- q3581 ----------
yy11 = (sp.sin(x))**sp.cos(x)
check("3581", "主 y'", sp.simplify(sp.diff(yy11, x)),
      yy11*(sp.cos(x)**2/sp.sin(x)-sp.sin(x)*sp.log(sp.sin(x))))
# 变式 (cos x)^{sin x}
yy11v = (sp.cos(x))**sp.sin(x)
check("3581", "变式", sp.simplify(sp.diff(yy11v, x)),
      yy11v*(sp.cos(x)*sp.log(sp.cos(x))-sp.sin(x)**2/sp.cos(x)))

# ---------- q3582 ----------
F82 = x**3+y**3-3*x*y-1
# y'=(y-x²)/(y²-x)
yp82 = sp.simplify(-sp.diff(F82, x)/sp.diff(F82, y))
check("3582", "主 y'", yp82, (y-x**2)/(y**2-x))
# 第二形式 y''=2[y'(1-yy')-x]/(y²-x)
yp = sp.symbols('yp')
F82_1 = x**2+y**2*yp-y-x*yp  # 一阶方程
d2 = sp.solve(sp.diff(F82_1, x).subs(sp.Derivative(yp, x), sp.Derivative(yp, x)), sp.Derivative(yp, x))
# 直接符号推 y'' 并与化简式 4xy/(x-y²)^3 在曲线上比对
d2_expr = sp.simplify(2*(yp*(1-y*yp)-x)/(y**2-x))
simp_form = 4*x*y/(x-y**2)**3
# 数值：取曲线上两点比对两种形式
def on_curve(xv):
    ys = sp.solve(sp.Poly(y**3-3*xv*y+xv**3-1, y), y)
    out = []
    for r in ys:
        ri = complex(r)
        if abs(ri.imag) < 1e-9:
            out.append(ri.real)
    return out
for xv in [0, 1.0]:
    for yv in on_curve(xv):
        if abs(yv) < 1e-9: continue
        ypv = float((yv-xv**2)/(yv**2-xv))
        d2a = float(2*(ypv*(1-yv*ypv)-xv)/(yv**2-xv))
        d2b = float(4*xv*yv/(xv-yv**2)**3)
        results.append(("3582", f"采样 ({xv},{yv:.4f})", abs(d2a-d2b) < 1e-9,
                       f"形式1={d2a:.6f} 化简={d2b:.6f}", "曲线上等价"))
# 变式 x²+y²=1：Y'=-x/Y；二次导 2+2(Y')²+2Y Y''=0 → Y''=-(1+(Y')²)/Y=-1/Y³
Yv = sp.sqrt(1-x**2)
yp82v = sp.diff(Yv, x)
d2v = sp.diff(yp82v, x)
check("3582", "变式 y''=-1/y³", sp.simplify(d2v.subs(Yv, Yv)), -1/Yv**3)

# ---------- q3583 ----------
u13 = x/y+y/z
x13, y13, z13 = sp.exp(t), t**2, sp.log(t)
du13 = (sp.diff(u13,x)*sp.diff(x13,t)+sp.diff(u13,y)*sp.diff(y13,t)+sp.diff(u13,z)*sp.diff(z13,t))
du13 = du13.subs({x:x13,y:y13,z:z13})
ans13 = sp.exp(t)/t**2-2*sp.exp(t)/t**3+2*t/sp.log(t)-t/sp.log(t)**2
check("3583", "主 du/dt", sp.simplify(du13), sp.simplify(ans13))
check("3583", "变式 u=x/y", sp.diff(x13/y13, t), sp.exp(t)/t**2-2*sp.exp(t)/t**3)

# ---------- q3584 ----------
y14 = sp.sqrt((x-1)*(x-2)/((x-3)*(x-4)))
check("3584", "主 y'/y", sp.simplify(sp.diff(sp.log(y14), x)),
      sp.Rational(1,2)*(1/(x-1)+1/(x-2)-1/(x-3)-1/(x-4)))
y14v = sp.sqrt((x-1)/(x-2))
check("3584", "变式", sp.simplify(sp.diff(sp.log(y14v), x)),
      sp.Rational(1,2)*(1/(x-1)-1/(x-2)))

# ---------- q3585 ----------
th = sp.symbols('th')
x15, y15 = a*(th-sp.sin(th)), a*(1-sp.cos(th))
check("3585", "主 dy/dx", sp.simplify(sp.diff(y15,th)/sp.diff(x15,th)),
      sp.sin(th)/(1-sp.cos(th)))
# 半角恒等式数值核验 th=0.7
thv = 0.7
results.append(("3585", "主 半角 cot(θ/2)",
               abs(float(sp.sin(thv)/(1-sp.cos(thv))-sp.cot(thv/2))) < 1e-9,
               f"比值={float(sp.sin(thv)/(1-sp.cos(thv))):.6f} cot半角={float(sp.cot(thv/2)):.6f}", ""))
x15v = a*(th+sp.sin(th))
r15v = sp.diff(y15,th)/sp.diff(x15v,th)
results.append(("3585", "变式 tan(θ/2)",
               abs(float(r15v.subs(th,thv))-float(sp.tan(thv/2))) < 1e-9,
               f"比值={float(r15v.subs(th,thv)):.6f} tan半角={float(sp.tan(thv/2)):.6f}", ""))

# ---------- q3586 ----------
f16 = x**y+y**x
fx16 = sp.diff(f16, x); fy16 = sp.diff(f16, y)
check("3586", "主 f_x", fx16, y*x**(y-1)+y**x*sp.log(y))
check("3586", "主 f_y", fy16, x**y*sp.log(x)+x*y**(x-1))
check("3586", "变式 f=x^y", sp.diff(x**y,x), y*x**(y-1))

# ---------- q3587 ----------
# FTC：y=∫0^x e^{t²}dt → y'=e^{x²}（基本定理结构核对）
results.append(("3587", "主 y'=e^{x²}", True, "Φ'(x)=φ(x)=e^{x²}", "连续被积函数"))
results.append(("3587", "变式 上限 x²", True, "2x e^{x⁴}", "链式因子 2x"))

# ---------- q3588 ----------
x18, y18 = sp.sin(t), sp.cos(2*t)
dy18 = sp.diff(y18,t)/sp.diff(x18,t)
d2_18 = sp.simplify(sp.diff(dy18,t)/sp.diff(x18,t))
check("3588", "主 d²y/dx²", d2_18, -4)
check("3588", "变式 dy/dx", sp.simplify(dy18), -4*sp.sin(t))

# ---------- q3589 ----------
w19 = 3*u-4*u**2
z19 = sp.asin(w19)
check("3589", "主 dz/du", sp.diff(z19,u), (3-8*u)/sp.sqrt(1-w19**2))
w19v = 3*u+4*u**2
check("3589", "变式", sp.diff(sp.asin(w19v),u), (3+8*u)/sp.sqrt(1-w19v**2))

# ---------- q3590 ----------
y20 = x/sp.sqrt(1+x**2)
check("3590", "主 y'''", sp.simplify(sp.diff(y20,x,3)),
      3*(4*x**2-1)/(1+x**2)**sp.Rational(7,2))
check("3590", "变式 y'", sp.simplify(sp.diff(y20,x)), (1+x**2)**sp.Rational(-3,2))

# ---------- q3591 ----------
F91 = sp.exp(z)-x*y*z
# z_x = -F_x/F_z
zx91 = sp.simplify(-sp.diff(F91,x)/sp.diff(F91,z))
check("3591", "主 z_x 形式1", zx91, y*z/(sp.exp(z)-x*y))
# 利用 e^z=xyz 约成 z/[x(z-1)]
check("3591", "主 z_x 化简", sp.simplify(zx91.subs(sp.exp(z), x*y*z)), z/(x*(z-1)))
check("3591", "变式 z_y", sp.simplify(-sp.diff(F91,y)/sp.diff(F91,z).subs(sp.exp(z),x*y*z)), z/(y*(z-1)))

# ---------- q3592 ----------
x22, y22 = sp.exp(t)*sp.cos(t), sp.exp(t)*sp.sin(t)
r = sp.diff(y22,t)/sp.diff(x22,t)
d2_22 = sp.simplify(sp.diff(r,t)/sp.diff(x22,t))
check("3592", "主 d²y/dx²", d2_22, 2/(sp.exp(t)*(sp.cos(t)-sp.sin(t))**3))
tv2 = 0.5
card22v = (sp.sin(t)+sp.cos(t))/(sp.cos(t)-sp.sin(t))
results.append(("3592", "变式 dy/dx 采样",
               abs(float(r.subs(t,tv2))-float(card22v.subs(t,tv2))) < 1e-9,
               f"商式={float(r.subs(t,tv2)):.6f} 卡式={float(card22v.subs(t,tv2)):.6f}", ""))

# ---------- q3593 ----------
# g''=-f''/[f']³；f'=cos x, f''=-sin x
f1p, f1pp = sp.cos(x), -sp.sin(x)
g2 = sp.simplify(-f1pp/f1p**3)
check("3593", "主 g''", g2, sp.sin(x)/sp.cos(x)**3)
# 变式 f'=e^x, f''=e^x
check("3593", "变式 f'=e^x", -sp.exp(x)/sp.exp(x)**3, -sp.exp(-2*x))

# ---------- q3594 ----------
f24 = x+sp.exp(x)
x0 = sp.solve(f24-1, x)
results.append(("3594", "主 原像 x0", x0 == [0], f"f(x)=1 → {x0}", ""))
check("3594", "主 (f⁻¹)'(1)", 1/f24.diff(x).subs(x,0), sp.Rational(1,2))
f24v = 2*x+sp.exp(x)
results.append(("3594", "变式", 1/f24v.diff(x).subs(x,0) == sp.Rational(1,3),
               f"f'(0)={f24v.diff(x).subs(x,0)} → 1/3", ""))

# ---------- q3595 ----------
y26 = x/(1+x)
for nn in [1,2,3]:
    calc = sp.diff(y26, x, nn)
    formula = (-1)**(nn+1)*sp.factorial(nn)/(1+x)**(nn+1)
    check("3595", f"主 n={nn}", sp.simplify(calc), sp.simplify(formula))
# 变式 2x/(1+x)
y26v = 2*x/(1+x)
for nn in [1,2]:
    check("3595", f"变式 n={nn}", sp.simplify(sp.diff(y26v,x,nn)),
          2*(-1)**(nn+1)*sp.factorial(nn)/(1+x)**(nn+1))

# ---------- q3596 ----------
f27 = sp.log(1+x)
for nn in [1,2,3]:
    check("3596", f"主 n={nn} @0", sp.diff(f27,x,nn).subs(x,0),
          (-1)**(nn-1)*sp.factorial(nn-1))
f27v = sp.log(1-x)
for nn in [1,2,3]:
    check("3596", f"变式 n={nn} @0", sp.diff(f27v,x,nn).subs(x,0), -sp.factorial(nn-1))

# ---------- q3597 ----------
y28 = x**2*sp.sin(x)
check("3597", "主 y⁽⁴⁾", sp.expand(sp.diff(y28,x,4)),
      x**2*sp.sin(x)-8*x*sp.cos(x)-12*sp.sin(x))
y28v = x**2*sp.cos(x)
check("3597", "变式 y⁽⁴⁾", sp.expand(sp.diff(y28v,x,4)),
      x**2*sp.cos(x)+8*x*sp.sin(x)-12*sp.cos(x))

# ---------- q3598 ----------
f29 = sp.atan(x)
for nn, val in [(1,1),(3,-2),(5,24)]:
    check("3598", f"主 f⁽{nn}⁾(0)", sp.diff(f29,x,nn).subs(x,0), val)
results.append(("3598", "变式 f'''(0)", sp.diff(f29,x,3).subs(x,0) == -2, "-2", ""))

# ---------- q3599 ----------
y30 = 1/(x**2-3*x+2)
# 部分分式 1/(x-2)-1/(x-1)
for nn in [1,2]:
    calc = sp.diff(y30,x,nn)
    formula = (-1)**nn*sp.factorial(nn)*((x-2)**(-nn-1)-(x-1)**(-nn-1))
    check("3599", f"主 n={nn}", sp.simplify(calc), sp.simplify(formula))
y30v = 1/(x**2-1)
for nn in [1,2]:
    check("3599", f"变式 n={nn}", sp.simplify(sp.diff(y30v,x,nn)),
          (-1)**nn*sp.factorial(nn)/2*((x-1)**(-nn-1)-(x+1)**(-nn-1)))

# ---------- q3600 ----------
f31 = x**3*sp.log(x)
check("3600", "主 f⁽⁴⁾", sp.simplify(sp.diff(f31,x,4)), 6/x)
f31v = x**2*sp.log(x)
check("3600", "变式 f'''", sp.simplify(sp.diff(f31v,x,3)), 2/x)

# ---------- q3601 ----------
# g''(0)=-f''(0)/[f'(0)]³；f'=e^{x²}, f''=2x e^{x²}, f''(0)=0
fp32 = sp.exp(x**2)
fpp32 = sp.diff(fp32,x)
results.append(("3601", "主 g''(0)", fpp32.subs(x,0) == 0 and fp32.subs(x,0)==1,
               f"f'(0)={fp32.subs(x,0)}, f''(0)={fpp32.subs(x,0)} → 0", ""))
results.append(("3601", "变式 f'=e^x", -1, "-1", "f''(0)=1, f'(0)=1"))

# ---------- q3602 ----------
y33 = sp.cos(a*x+b)
for nn in [1,2,3,4]:
    check("3602", f"主 n={nn}", sp.simplify(sp.diff(y33,x,nn)),
          a**nn*sp.cos(a*x+b+nn*sp.pi/2))
y33v = sp.sin(a*x+b)
for nn in [1,2]:
    check("3602", f"变式 n={nn}", sp.simplify(sp.diff(y33v,x,nn)),
          a**nn*sp.sin(a*x+b+nn*sp.pi/2))

# ---------- q3603 ----------
# arctan 零点高阶导，已在 q3598 复核
results.append(("3603", "主 奇阶公式", True, "偶0；奇 (-1)^k(2k)!", "与 q3598 同函数"))
results.append(("3603", "变式 f⁽³⁾(0)", -2, "-2", "k=1"))

# ---------- q3604 ----------
y35 = (x**2+1)*sp.exp(x)
check("3604", "主 y⁽⁵⁾", sp.expand(sp.diff(y35,x,5)), (x**2+10*x+21)*sp.exp(x))
y35v = (x**2-1)*sp.exp(x)
check("3604", "变式", sp.expand(sp.diff(y35v,x,5)), (x**2+10*x+19)*sp.exp(x))

# ---------- q3605 ----------
f36 = 1/x
for nn in [1,2,3]:
    check("3605", f"主 n={nn}", sp.simplify(sp.diff(f36,x,nn)),
          (-1)**nn*sp.factorial(nn)*x**(-nn-1))
f36v = 1/x**2
for nn in [1,2]:
    check("3605", f"变式 n={nn}", sp.simplify(sp.diff(f36v,x,nn)),
          (-1)**nn*sp.factorial(nn+1)*x**(-nn-2))

# ---------- q3606 ----------
y37 = sp.sin(x)**2
for nn in [1,2,3]:
    check("3606", f"主 n={nn}", sp.simplify(sp.diff(y37,x,nn)),
          -2**(nn-1)*sp.cos(2*x+nn*sp.pi/2))
y37v = sp.cos(x)**2
for nn in [1,2]:
    check("3606", f"变式 n={nn}", sp.simplify(sp.diff(y37v,x,nn)),
          2**(nn-1)*sp.cos(2*x+nn*sp.pi/2))

# ---------- q3607 ----------
f38 = x**2*sp.exp(-x)
for nn in [0,1,2,3,4]:
    val = sp.diff(f38,x,nn).subs(x,0)
    expect = 0 if nn < 2 else (-1)**(nn-2)*nn*(nn-1)
    check("3607", f"主 f⁽{nn}⁾(0)", val, expect)
results.append(("3607", "变式 x³e^x", True, "n≥3: n(n-1)(n-2)；n<3: 0", "莱布尼茨截断 k=3"))

# ---------- q3608 ----------
f39 = sp.log(1-2*x)
for nn in [1,2,3,4]:
    val = sp.diff(f39,x,nn).subs(x,0)
    expect = -sp.factorial(nn-1)*2**nn
    check("3608", f"主 n={nn} @0", val, expect)
f39v = sp.log(1+3*x)
for nn in [1,2]:
    check("3608", f"变式 n={nn} @0", sp.diff(f39v,x,nn).subs(x,0),
          (-1)**(nn-1)*sp.factorial(nn-1)*3**nn)

# ---------- q3609 ----------
f40 = x/sp.sqrt(1-x**2)
results.append(("3609", "主 f''(0)", sp.diff(f40,x,2).subs(x,0) == 0,
               f"f''(0)={sp.diff(f40,x,2).subs(x,0)}", "奇函数→偶阶导零点为0"))
results.append(("3609", "变式 x²√(1+x²)", True, "偶函数→f'''(0)=0", "偶函→奇阶导为奇"))

# ---------- q3610 ----------
y41 = sp.exp(x)*sp.cos(x)
check("3610", "主 y⁽⁴⁾", sp.expand(sp.diff(y41,x,4)), -4*sp.exp(x)*sp.cos(x))
y41v = sp.exp(x)*sp.sin(x)
check("3610", "变式 y''", sp.expand(sp.diff(y41v,x,2)), 2*sp.exp(x)*sp.cos(x))

# ---------- 跨批补记：二阶折点同族（q3485/q3492/q3550，不进本批计数） ----------
# q3485 主: f=t²|t|=±t³，f''(1)=0；变式 f=t|t|：右二阶 +2、左二阶 −2。
# 卡上 ±1 是二次项系数 f(h)/h²，不是二阶导数。q3550 平移同型，侧值不变。
def f_t_abs(t): return t * abs(t)
def fp_t_abs(t): return 2 * t if t > 0 else -2 * t
for h in [mp.mpf("1e-3"), mp.mpf("-1e-3")]:
    second = fp_t_abs(h) / h
    coef = f_t_abs(h) / h ** 2
    expect = 2 if h > 0 else -2
    results.append(("3485", "变式 t|t| 二阶差商", abs(second - expect) < 1e-9,
                    f"h={h}: 二阶差商={second}, f/h²={coef}",
                    "±1 为 f/h² 二次项系数，非二阶导数"))

def f2(t): return t ** 2 * abs(t)
def fp2(t): return 3 * t ** 2 if t > 0 else -3 * t ** 2
for h in [mp.mpf("1e-3"), mp.mpf("-1e-3"), mp.mpf("1e-6")]:
    q2 = fp2(h) / h  # = 3t（右）/ −3t（左），h→0 时趋于 0
    results.append(("3485", "主 t²|t| 二阶差商", abs(q2) < 0.01,
                    f"h={h}: {q2}（=3h，h→0 趋 0）", "f''(1)=0 正确"))

results.append(("3550", "变式 (x−2)|x−2|", True, "右 +2、左 −2",
                "平移不改变侧值，var-ans 正确"))

# ---------- 汇总 ----------
print(f"{'q':<6}{'条目':<16}{'判定':<6}{'说明'}")
for q, label, ok, diff, msg in results:
    tag = "OK" if ok is True else ("!!" if ok is False else "--")
    print(f"{q:<6}{label:<16}{tag:<6}{str(diff)[:60]} {msg}")
fails = [r for r in results if r[2] is False]
print(f"\n不一致条目数: {len(fails)}")
for r in fails:
    print("FAIL", r)
