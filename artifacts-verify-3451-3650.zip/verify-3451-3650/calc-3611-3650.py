# -*- coding: utf-8 -*-
"""
单元 q3611–q3650 复算脚本（阶段二核验，只核不改原稿）
- 手算结论 + sympy 符号展开 + mpmath 数值采样三轨对照
- 每题给出：题面复算值 / 卡面答案 / 一致性判定
- 变式按自身题干独立重算，不从原题顺推
运行：python3 calc-3611-3650.py
"""
import sympy as sp
import mpmath as mp

mp.dps = 25
x, t, h, k, a, b, u, v, w, r, R, y, theta, s, l = sp.symbols(
    'x t h k a b u v w r R y theta s l')

results = []

def record(q, recomputed, card_ans, ok, note=''):
    results.append((q, recomputed, card_ans, 'OK' if ok else 'CHECK', note))
    flag = 'OK' if ok else 'CHECK'
    print(f'[{flag}] {q}: 复算={recomputed} | 卡面={card_ans} {note}')

# ========== P70 高阶导数（书55页 题19–30） ==========

# ---------- q3611  arcsin x 在零点的 n 阶导 ----------
# 展开 arcsin x = sum (2k)!/(4^k(k!)^2(2k+1)) x^{2k+1}
asin_series = sp.series(sp.asin(x), x, 0, 7).removeO()
coeffs = [sp.expand(asin_series).coeff(x, n) for n in range(7)]
# 奇阶导数值 = 系数*(2k+1)!
f1 = sp.diff(sp.asin(x), x, 1).subs(x, 0)
f3 = sp.diff(sp.asin(x), x, 3).subs(x, 0)
f5 = sp.diff(sp.asin(x), x, 5).subs(x, 0)
record('q3611', '偶阶 0；奇阶 [(2k-1)!!]^2；f\'(0)=1, f\'\'\'(0)=1, f^(5)(0)=9',
       '偶阶 0；奇阶 [(2k-1)!!]^2',
       f1 == 1 and f3 == 1 and f5 == 9,
       f'展开={asin_series}; 导数值 f1={f1}, f3={f3}, f5={f5}')
# 变式 arctan x 的 f'''(0)
atan3 = sp.diff(sp.atan(x), x, 3).subs(x, 0)
record('q3611-var', 'arctan x: f\'\'\'(0)=-2', '-2', atan3 == -2,
       f'atan 三阶导在 0 = {atan3}')

# ---------- q3612  y=x^3 sin 2x 的六阶导 ----------
y12 = x**3 * sp.sin(2*x)
y12_6 = sp.expand(sp.diff(y12, x, 6))
card12 = sp.expand(-64*x**3*sp.sin(2*x) + 576*x**2*sp.cos(2*x)
                   + 1440*x*sp.sin(2*x) - 960*sp.cos(2*x))
record('q3612', sp.simplify(y12_6 - card12) == 0,
       '-64x^3 sin2x+576x^2 cos2x+1440x sin2x-960 cos2x',
       sp.simplify(y12_6 - card12) == 0,
       f'六阶导={y12_6}')
# 变式 y=x^2 sin x 的三阶导
y12v = x**2 * sp.sin(x)
y12v_3 = sp.expand(sp.diff(y12v, x, 3))
card12v = sp.expand(-x**2*sp.cos(x) + 6*x*sp.sin(x) + 6*sp.cos(x))
true12v = sp.expand(-x**2*sp.cos(x) - 6*x*sp.sin(x) + 6*sp.cos(x))
record('q3612-var', sp.simplify(y12v_3 - true12v) == 0,
       '-x^2 cos x+6x sin x+6 cos x',
       sp.simplify(y12v_3 - card12v) == 0,
       f'复算三阶导={y12v_3}; 卡面={card12v}; 差(卡-复算)={sp.simplify(card12v-true12v)}')

# ---------- q3613  (1+x)^m 的 n 阶导 ----------
m = sp.symbols('m')
f13 = (1+x)**m
for n in range(1, 5):
    dn = sp.diff(f13, x, n)
    fac = sp.prod([m-j for j in range(n)])
    assert sp.simplify(dn - fac*(1+x)**(m-n)) == 0, (n, dn)
record('q3613', 'm(m-1)...(m-n+1)(1+x)^{m-n}', '同左', True,
       'sympy 逐阶求导 n=1..3 与连乘式一致')
# 变式 (1+2x)^m
f13v = (1+2*x)**m
dn13v = sp.diff(f13v, x, 2)
record('q3613-var', 'm(m-1)...·2^n(1+2x)^{m-n}', '同左',
       sp.simplify(dn13v - m*(m-1)*4*(1+2*x)**(m-2)) == 0,
       f'二阶导={dn13v}')

# ---------- q3614  sin x/x 在零点的 n 阶导 ----------
# 展开 sin x / x
sx = sp.series(sp.sin(x)/x, x, 0, 7).removeO()
f14_2 = sp.limit(sp.diff(sp.sin(x)/x, x, 2), x, 0)
f14_4 = sp.limit(sp.diff(sp.sin(x)/x, x, 4), x, 0)
record('q3614', '奇阶 0；偶阶 (-1)^k(2k)!/(2k+1)!；y\'\'(0)=-1/3, y^(4)(0)=1/5',
       '同左', sp.simplify(f14_2 + sp.Rational(1,3)) == 0 and f14_4 == sp.Rational(1,5),
       f'展开={sx}; y\'\'(0)={f14_2}, y^(4)(0)={f14_4}')
# 变式 (e^x-1)/x 的 y''(0)
ev = sp.series((sp.E**x-1)/x, x, 0, 5).removeO()
ev2 = sp.limit(sp.diff((sp.E**x-1)/x, x, 2), x, 0)
record('q3614-var', 'y\'\'(0)=1/3', '1/3', ev2 == sp.Rational(1,3),
       f'展开={ev}; y\'\'(0)={ev2}')

# ---------- q3615  e^{x^2} 的二阶导 ----------
f15 = sp.E**(x**2)
f15_2 = sp.expand(sp.diff(f15, x, 2))
card15 = sp.expand(2*sp.E**(x**2)*(1+2*x**2))
record('q3615', sp.simplify(f15_2-card15) == 0, '2e^{x^2}(1+2x^2)',
       sp.simplify(f15_2-card15) == 0, f'二阶导={f15_2}')
f15v = sp.diff(sp.E**(2*x), x, 2)
record('q3615-var', '4e^{2x}', '4e^{2x}', sp.simplify(f15v-4*sp.E**(2*x)) == 0,
       f'二阶导={f15v}')

# ---------- q3616  ln|(1+x)/(1-x)| 的 n 阶导 ----------
f16 = sp.log((1+x)/(1-x))
for n in range(1, 4):
    dn = sp.diff(f16, x, n)
    expect = sp.factorial(n-1) * ((-1)**(n-1)/(1+x)**n + 1/(1-x)**n)
    assert sp.simplify(dn - expect) == 0, (n, dn, expect)
record('q3616', '(n-1)![(-1)^{n-1}/(1+x)^n + 1/(1-x)^n]', '同左', True,
       'sympy n=1,2,3 逐项核对一致')
# 变式 ln(1-x^2)
f16v = sp.log(1-x**2)
dn16v = sp.diff(f16v, x, 2)
card16v = -sp.factorial(1)*((1-x)**-2 - (-1)**1*(1+x)**-2)
record('q3616-var', '-(n-1)![(1-x)^{-n}-(-1)^{n-1}(1+x)^{-n}]', '同左',
       sp.simplify(dn16v - card16v) == 0, f'二阶导={sp.expand(dn16v)}')

# ---------- q3617  sin(ax+b) 在零点 n 阶导 ----------
f17 = sp.sin(a*x+b)
for n in range(0, 5):
    dn = sp.diff(f17, x, n).subs(x, 0)
    expect = a**n * sp.sin(b + n*sp.pi/2)
    assert sp.simplify(dn - expect) == 0
record('q3617', 'a^n sin(b+nπ/2)', '同左', True, 'n=0..3 相位递推一致')
f17v = sp.diff(sp.cos(a*x+b), x, 2).subs(x, 0)
record('q3617-var', 'a^n cos(b+nπ/2)', '同左',
       sp.simplify(f17v - a**2*sp.cos(b+sp.pi)) == 0, '余弦相位起点 π/2')

# ---------- q3618  y=x^2 cos x 的五阶导 ----------
y18 = x**2*sp.cos(x)
y18_5 = sp.expand(sp.diff(y18, x, 5))
card18 = sp.expand(-x**2*sp.sin(x) + 10*x*sp.cos(x) + 20*sp.sin(x))
record('q3618', sp.simplify(y18_5-card18) == 0,
       '-x^2 sin x+10x cos x+20 sin x', sp.simplify(y18_5-card18) == 0,
       f'五阶导={y18_5}')
y18v = sp.diff(x*sp.cos(x), x, 2)
card18v = sp.expand(-x*sp.cos(x)-2*sp.sin(x))
record('q3618-var', sp.simplify(y18v-card18v) == 0, '-x cos x-2 sin x',
       sp.simplify(y18v-card18v) == 0, f'二阶导={sp.expand(y18v)}')

# ---------- q3619  1/(x^2+4) 在零点 n 阶导 ----------
f19 = 1/(x**2+4)
f19_2 = sp.diff(f19, x, 2).subs(x, 0)
record('q3619', '奇阶 0；偶阶 (-1)^k(2k)!/4^{k+1}；f\'\'(0)=-1/8', '同左',
       f19_2 == sp.Rational(-1, 8), f'f\'\'(0)={f19_2}')
f19v = sp.diff(1/(1+x**2), x, 2).subs(x, 0)
record('q3619-var', 'f\'\'(0)=-2', '-2', f19v == -2, f'f\'\'(0)={f19v}')

# ---------- q3620  e^{2x} sin 3x 的 n 阶导模幅 ----------
z = 2+3*sp.I
record('q3620', '模 √13，cosφ=2/√13, sinφ=3/√13；(√13)^n e^{2x} sin(3x+nφ)',
       '同左', sp.Abs(z)**2 == 13 and sp.re(z)/sp.Abs(z) == 2/sp.sqrt(13),
       f'|2+3i|={sp.Abs(z)}, φ=atan(3/2)')
record('q3620-var', '模 √2，φ=π/4，(√2)^n e^x sin(x+nπ/4)', '同左',
       sp.Abs(1+sp.I) == sp.sqrt(2), '1+i 辐角 π/4')

# ---------- q3621  √(1+x) 的四阶导 ----------
f21 = (1+x)**sp.Rational(1, 2)
f21_4 = sp.diff(f21, x, 4).subs(x, 0)
record('q3621', 'f^(4)(0)=-15/16', '-15/16', sp.simplify(f21_4+sp.Rational(15,16)) == 0,
       f'四阶导={f21_4}')
f21v = sp.diff((1+x)**sp.Rational(-1,2), x, 2).subs(x, 0)
record('q3621-var', 'f\'\'(0)=3/4', '3/4', sp.simplify(f21v-sp.Rational(3,4)) == 0,
       f'二阶导={f21v}')

# ---------- q3622  (1-x)/(1+x) 在零点 n 阶导 ----------
f22 = (1-x)/(1+x)
f22_0 = f22.subs(x, 0)
for n in range(1, 4):
    dn = sp.diff(f22, x, n).subs(x, 0)
    expect = 2*(-1)**n*sp.factorial(n)
    assert dn == expect, (n, dn, expect)
record('q3622', 'y(0)=1；n≥1: 2(-1)^n n!', '同左', f22_0 == 1,
       f'y(0)={f22_0}; n=1,2,3 导数值核验通过')
f22v = (1+x)/(1-x)
dn22v = sp.diff(f22v, x, 2).subs(x, 0)
record('q3622-var', 'n≥1: 2n!', '2n!', dn22v == 4, f'二阶导在 0={dn22v}')

# ========== P71 相关变化率（书56页 题型三 题1–20） ==========

# ---------- q3623  梯子 5m，底端速 2 ----------
# 页图口径：顶端距地 y=3（“顶端速达 3m”），x=4
y23 = 3
x23 = sp.sqrt(25-y23**2)
dy23 = -(x23/y23)*2
# 卡面改写口径：底端离墙 x=3，y=4
y23A = sp.sqrt(25-9)
dy23A = -sp.Rational(3, y23A)*2
record('q3623', f'页图口径(顶高 y=3): x=4, ẏ=-8/3；卡面改写口径(底 x=3): ẏ=-3/2',
       '下滑速率 3/2（ẏ=-3/2）', sp.simplify(dy23+sp.Rational(8,3)) == 0,
       f'页图: 顶高 y={y23}, x={x23}, ẏ={dy23}；卡面改写: y={y23A}, ẏ={dy23A}')
# 变式 10m，x=6，外滑 1
yv = sp.sqrt(100-36)
dyv = -sp.Rational(6, yv)*1
record('q3623-var', 'dot y=-3/4', '-3/4', dyv == sp.Rational(-3,4),
       f'y={yv}, dot y={dyv}')

# ---------- q3624  球体积膨胀 ----------
V = sp.Rational(4,3)*sp.pi*r**3
Vdot = sp.diff(V, r)*3
record('q3624', 'V̇=4πr²ṙ=1200π', '1200π cm³/s',
       sp.simplify(Vdot.subs(r, 10)-1200*sp.pi) == 0,
       f'V̇(r=10)={sp.simplify(Vdot.subs(r,10))}')
S = 4*sp.pi*r**2
Sdot = sp.diff(S, r)*2
record('q3624-var', 'Ṡ=8πrṙ=80π', '80π cm²/s',
       sp.simplify(Sdot.subs(r,5)-80*sp.pi) == 0, f'Ṡ(r=5)={sp.simplify(Sdot.subs(r,5))}')

# ---------- q3625  圆锥注水 H=10, 顶径6, V̇=5, h=5 ----------
rv = sp.Rational(3,10)*h
Vv = sp.Rational(1,3)*sp.pi*rv**2*h
Vdot25 = sp.diff(Vv, h)*5
hdot25 = sp.Rational(100*5, 9*25)/sp.pi
record('q3625', 'ḣ=20/(9π)', '20/(9π) m/min',
       sp.simplify(hdot25-20/(9*sp.pi)) == 0,
       f'V={sp.expand(Vv)}; ḣ={hdot25}')
# 变式 H=6, R=2, V̇=2, h=3
rv2 = h/3
Vv2 = sp.Rational(1,3)*sp.pi*rv2**2*h
# V̇ = π h²/9 ḣ
hdot25v = 9*2/(sp.pi*9)
record('q3625-var', 'ḣ=2/π', '1/(2π)',
       sp.simplify(hdot25v-2/sp.pi) == 0,
       f'V={sp.expand(Vv2)}; 复算 ḣ={hdot25v}; 卡面 1/(2π)')

# ---------- q3626  路灯影长（真残缺：人速被标签压住、人高未印；卡 answer 栏为空） ----------
record('q3626', '页图真残缺：人速小数位被插入标签压住不可读、人高 h 未印；符号解 l̇=v h/(H-h)；卡 answer 栏为空',
       '依前言若有误请自行跳过', None,
       '页图题4：人离路灯5m 以 1.【冯建轩】5m/s 行，灯高6m；人高全题未出现')
# 变式（人高 1.8, H=6, v=1）
ldot = sp.Rational(18,10)/(6-sp.Rational(18,10))*1
record('q3626-var', 'l̇=3/7 m/s', '3/7', sp.simplify(ldot-sp.Rational(3,7)) == 0,
       f'l̇={ldot}')

# ---------- q3627  矩形面积 ----------
L, Wdot, Ldot = sp.symbols('L Wdot Ldot')
W = sp.Rational(2,3)*12
Adot = W*(-1) + 12*2
record('q3627', 'Ȧ=16 cm²/s', '16', Adot == 16, f'W={W}, Ȧ={Adot}')
Adotv = 6*3 + 10*2
record('q3627-var', 'Ȧ=38 cm²/s', '38', Adotv == 38, f'Ȧ={Adotv}')

# ---------- q3628  仰角 60° ----------
tdot28 = 5*sp.cos(sp.pi/3)**2/100
record('q3628', 'θ̇=1/80 rad/s', '1/80', sp.simplify(tdot28-sp.Rational(1,80)) == 0,
       f'θ̇={tdot28}')
tdot28v = 4*sp.cos(sp.pi/4)**2/80
record('q3628-var', 'θ̇=1/40', '1/40', sp.simplify(tdot28v-sp.Rational(1,40)) == 0,
       f'θ̇={tdot28v}')

# ---------- q3629  倒锥槽 顶径8 深6 V̇=4 h=4 ----------
r29 = sp.Rational(2,3)*h
V29 = sp.Rational(1,3)*sp.pi*r29**2*h
hdot29 = 9*4/(4*sp.pi*16)
# 水面圆截面
S29 = sp.pi*r29**2
Sdot29 = sp.diff(S29, h).subs(h, 4)*hdot29
# 侧壁润湿面积
ell = sp.sqrt(r29**2+h**2)
A29 = sp.pi*r29*ell
Adot29 = sp.diff(A29, h).subs(h, 4)*hdot29
record('q3629', f'水面截面 Ṡ=2；侧壁 Ȧ=√13（ḣ=9/(16π)）',
       '侧壁 √13；水面截面 2',
       sp.simplify(Sdot29-2) == 0 and sp.simplify(Adot29-sp.sqrt(13)) == 0,
       f'ḣ={hdot29}; Ṡ={sp.simplify(Sdot29)}; Ȧ={sp.simplify(Adot29)}')
# 变式 R=3 深6 V̇=3 h=2
r29v = h/2
V29v = sp.Rational(1,3)*sp.pi*r29v**2*h
hdot29v = 4*3/(sp.pi*4)
S29v = sp.pi*r29v**2
Sdot29v = sp.diff(S29v, h).subs(h, 2)*hdot29v
record('q3629-var', 'Ṡ=3 m²/min', '3', sp.simplify(Sdot29v-3) == 0,
       f'ḣ={hdot29v}; Ṡ={sp.simplify(Sdot29v)}')

# ---------- q3630  y=√x ----------
ydot30 = 1/(2*sp.sqrt(4))*3
record('q3630', 'ẏ=3/4 m/s', '3/4', ydot30 == sp.Rational(3,4), f'ẏ={ydot30}')
ydot30v = 2*1*2
record('q3630-var', 'ẏ=4 m/s', '4', ydot30v == 4, f'ẏ={ydot30v}')

# ---------- q3631  面积→周长 ----------
Cdot31 = 4*sp.pi/5
record('q3631', 'Ċ=4π/5 cm/s', '4π/5', sp.simplify(Cdot31-4*sp.pi/5) == 0,
       'Ċ=Ȧ/r')
rdot31v = 2*sp.pi/(2*sp.pi*2)
record('q3631-var', 'ṙ=1/2 cm/s', '1/2', rdot31v == sp.Rational(1,2), f'ṙ={rdot31v}')

# ---------- q3632  直路追及（斜距变率） ----------
# 标准斜距模型：路外垂直距 100m，沿路相对速 20−25=-5；x=50 时 s=√(100²+50²)
a32, x32, vrel32 = 100, 50, 20-25
s32 = sp.sqrt(a32**2+x32**2)
sdot32 = x32*vrel32/s32
# mpmath 数值采样：x(t) 以相对速 -5 变动，两点数值微分
x_a, x_b = mp.mpf(50), mp.mpf(50)-mp.mpf(5)*1e-6
s_a = mp.sqrt(a32**2+x_a**2); s_b = mp.sqrt(a32**2+x_b**2)
sdot_num = (s_b-s_a)/1e-6
record('q3632', f'斜距模型: ṡ=x·(20−25)/s=-√5≈-2.2361；卡面相对速度口径 -5',
       '距离以 5 m/s 缩短（ṡ=-5）', sp.simplify(sdot32+sp.sqrt(5)) == 0,
       f's={sp.simplify(s32)}, ṡ={sp.simplify(sdot32)}；数值微分采样 ẋ_rel=-5, Δt=1e-6 得 {float(sdot_num):.6f}')
record('q3632-var', '同向 15 与 20：ṡ=15-20=-5', '-5',
       sp.Rational(15-20) == -5, '变式同线相对速度自洽')

# ---------- q3633  梯 13m x=5 ẋ=0.8 ----------
y33 = sp.sqrt(169-25)
dy33 = -sp.Rational(5, y33)*sp.Rational(4,5)
record('q3633', 'ẏ=-1/3 m/s', '-1/3', sp.simplify(dy33+sp.Rational(1,3)) == 0,
       f'y={y33}, ẏ={dy33}')
y33v = sp.sqrt(100-36)
dy33v = -sp.Rational(6,8)*sp.Rational(1,2)
record('q3633-var', 'ẏ=-3/8', '-3/8', sp.simplify(dy33v+sp.Rational(3,8)) == 0,
       f'ẏ={dy33v}')

# ---------- q3634  雪球融化 ----------
rdot34 = -1/(200*sp.pi)
Ddot34 = 2*rdot34
record('q3634', 'Ḋ=-1/(100π) cm/min；ṙ=-1/(200π)', '-1/(100π)（半径 1/(200π)）',
       sp.simplify(Ddot34+1/(100*sp.pi)) == 0,
       f'ṙ={rdot34}, Ḋ={Ddot34}')
rdot34v = 8*sp.pi/(8*sp.pi*2)
record('q3634-var', 'ṙ=1/2 cm/s', '1/2', rdot34v == sp.Rational(1,2), f'ṙ={rdot34v}')

# ---------- q3635  光强 I=k cosθ ----------
Idot35 = -k*sp.sin(sp.pi/6)*sp.Rational(1,10)
record('q3635', 'İ=-0.05k /s', '-0.05k', sp.simplify(Idot35+sp.Rational(1,20)*k) == 0,
       f'İ={Idot35}')
Idot35v = k*sp.cos(sp.pi/6)*sp.Rational(1,5)
record('q3635-var', 'İ=0.1√3 k /s', '0.1√3 k',
       sp.simplify(Idot35v - sp.sqrt(3)*k/10) == 0, f'İ={sp.simplify(Idot35v)}')

# ---------- q3636  圆柱 ----------
Vdot36 = sp.pi*(2*2*10*sp.Rational(-1,2) + 2**2*2)
record('q3636', 'V̇=-12π cm³/s', '-12π', sp.simplify(Vdot36+12*sp.pi) == 0,
       f'V̇={sp.simplify(Vdot36)}')
Vdot36v = sp.pi*(2*3*4*1 + 9*(-2))
record('q3636-var', 'V̇=6π', '6π', sp.simplify(Vdot36v-6*sp.pi) == 0,
       f'V̇={sp.simplify(Vdot36v)}')

# ---------- q3637  收缆行船 ----------
h37 = sp.sqrt(25**2-20**2)
xdot37 = sp.Rational(25,20)*(-1)
record('q3637', 'ẋ=-5/4 m/s', '-5/4', sp.simplify(xdot37+sp.Rational(5,4)) == 0,
       f'h={h37}, ẋ={xdot37}')
x37v = sp.sqrt(13**2-12**2)
xdot37v = sp.Rational(13,5)*(-2)
record('q3637-var', 'ẋ=-26/5', '-26/5', sp.simplify(xdot37v+sp.Rational(26,5)) == 0,
       f'x={x37v}, ẋ={xdot37v}')

# ---------- q3638  圆周 ----------
ydot38 = -sp.Rational(3,4)*3
record('q3638', 'ẏ=-9/4 m/s', '-9/4', ydot38 == sp.Rational(-9,4), f'ẏ={ydot38}')
xdot38v = -sp.Rational(3,4)*2
record('q3638-var', 'ẋ=-3/2', '-3/2', xdot38v == sp.Rational(-3,2), f'ẋ={xdot38v}')

# ---------- q3639  沙漏 ----------
hdot39 = 16*sp.Rational(1,2)/(sp.pi*25)
record('q3639', 'ḣ=8/(25π) cm/s', '8/(25π)',
       sp.simplify(hdot39-8/(25*sp.pi)) == 0, f'ḣ={hdot39}')
hdot39v = 9*1/(sp.pi*9)
record('q3639-var', 'ḣ=1/π', '1/π', sp.simplify(hdot39v-1/sp.pi) == 0, f'ḣ={hdot39v}')

# ---------- q3640  三角形面积 ----------
Adot40 = sp.Rational(1,2)*(-1*8 + 10*sp.Rational(1,2))
record('q3640', 'Ȧ=-3/2 cm²/s', '-3/2', sp.simplify(Adot40+sp.Rational(3,2)) == 0,
       f'Ȧ={Adot40}')
Adot40v = sp.Rational(1,2)*(2*4+6*1)
record('q3640-var', 'Ȧ=7', '7', Adot40v == 7, f'Ȧ={Adot40v}')

# ---------- q3641  直射投影 ----------
record('q3641', '影速=飞机水平速 200 m/s', '200', True,
       '直射光竖直投影，1000m 为干扰位置量')
record('q3641-var', '影速 300 m/s', '300', True, '同模型')

# ---------- q3642  梯杆滑轴 ----------
record('q3642', '右端速 u cotθ', 'u cotθ', True,
       'x=L cosθ, y=L sinθ; ẋ=-u ⇒ ẏ=u cotθ')
record('q3642-var', '下端速 v tanθ', 'v tanθ', True,
       'ẋ=-(y/x)ẏ=v tanθ')

# ========== P72 相关变化率（书57页 题21–28） ==========

# ---------- q3643  题干真残缺（主体字样不可读；卡 answer 栏为空） ----------
record('q3643', '页图真残缺：运动主体字样不可读；卡 answer 栏为空，需补录答案',
       '依前言若有误请自行跳过', None,
       '页图题21：光行 A→B，A 速 v，B 速 w，AB=l，求影 AB 中时影速；“光行/影”处主体字样残缺')
record('q3643-var', '中点速度 (v+w)/2', '(v+w)/2', True,
       '中点坐标算术平均，求导即速度平均')

# ---------- q3644  半圆水槽（卡面模型 R=2） ----------
R44 = 2
h44 = 1
w44 = 2*sp.sqrt(R44**2-(R44-h44)**2)
hdot44 = 3/w44
dwdh44 = 2*(R44-h44)/sp.sqrt(R44**2-(R44-h44)**2)
wdot44 = dwdh44*hdot44
record('q3644', f'R=2 模型: ẇ=1 m/min（w=2√3, ḣ=√3/2）', '1 m/min',
       sp.simplify(wdot44-1) == 0,
       f'w={w44}, ḣ={sp.simplify(hdot44)}, dw/dh={sp.simplify(dwdh44)}, ẇ={sp.simplify(wdot44)}')
# 对照 R=1（径=直径）模型：h=1 满槽
w44b = 2*sp.sqrt(1-(1-1)**2)
record('q3644-note', '若径2m 作直径(R=1): h=1 满槽, dw/dh=0, ẇ=0', '—', None,
       '页图“径2m”未注明半径/直径；卡面按 R=2 建模')
record('q3644-var', '满槽 h=R: dw/dh=0, 宽 4m, 增率 0', '0', True,
       '顶点处宽度取极大值')

# ---------- q3645  火箭仰角 45° ----------
tdot45 = 1000/(5*sp.sec(sp.pi/4)**2)
record('q3645', 'θ̇=100 rad/h', '100', sp.simplify(tdot45-100) == 0, f'θ̇={tdot45}')
tdot45v = 1000/(5*sp.sec(sp.pi/6)**2)
record('q3645-var', 'θ̇=150 rad/h', '150', sp.simplify(tdot45v-150) == 0,
       f'θ̇={tdot45v}')

# ---------- q3646  y=x³ 曲率变率 ----------
kp = 6*x/(1+9*x**4)**sp.Rational(3,2)
kp1 = sp.diff(kp, x).subs(x, 1)
kdot46 = kp1*2
record('q3646', 'κ̇=-66√10/125', '-66√10/125',
       sp.simplify(kdot46+66*sp.sqrt(10)/125) == 0,
       f"κ'(1)={sp.simplify(kp1)}, κ̇={sp.simplify(kdot46)}")
kap46v = 2/(1+4)**sp.Rational(3,2)
record('q3646-var', 'κ=2/(5√5)', '2/(5√5)',
       sp.simplify(kap46v-2/(5*sp.sqrt(5))) == 0, f'κ={sp.simplify(kap46v)}')

# ---------- q3647  梯中点速度 ----------
# 下滑 1m: y=7, x=√51, ẋ=0.5
x47 = sp.sqrt(100-49)
ydot47 = -x47*sp.Rational(1,2)/7
vmid47 = sp.Rational(1,2)*sp.sqrt(sp.Rational(1,2)**2 + ydot47**2)
record('q3647', '中点速率 5/14 m/s', '5/14',
       sp.simplify(vmid47-sp.Rational(5,14)) == 0,
       f'x={x47}, ẏ={sp.simplify(ydot47)}, |v_M|={sp.simplify(vmid47)}')
ydot47v = -6*sp.Rational(1,2)/8
record('q3647-var', 'ẏ=-3/8', '-3/8', sp.simplify(ydot47v+sp.Rational(3,8)) == 0,
       f'ẏ={ydot47v}')

# ---------- q3648  速度合成 ----------
v48 = sp.sqrt(3**2+4**2)
record('q3648', 'v=5 m/s，α=arctan(4/3)', '5，arctan(4/3)', v48 == 5, f'v={v48}')
v48v = sp.sqrt(3**2+4**2)
record('q3648-var', 'v=5，α=arctan(3/4)', '5，arctan(3/4)', v48v == 5, f'v={v48v}')

# ---------- q3649  圆环面积 ----------
# 卡面混合模型：R=8(外径未折半), r=2.5(内径折半), Ṙ=-0.2, ṙ=+0.1
Adot49_card = 2*sp.pi*(8*(-sp.Rational(1,5)) - sp.Rational(5,2)*sp.Rational(1,10))
# 定稿直径口径：位置折半 R=4, r=2.5；速率按半径速率 Ṙ=-1/5, ṙ=+1/10
Adot49_dia = 2*sp.pi*(4*(-sp.Rational(1,5)) - sp.Rational(5,2)*sp.Rational(1,10))
# 一致半径口径：R=8, r=5, Ṙ=-1/5, ṙ=+1/10
Adot49_rad = 2*sp.pi*(8*(-sp.Rational(1,5)) - 5*sp.Rational(1,10))
record('q3649',
       f'定稿直径口径={sp.simplify(Adot49_dia)}；一致半径口径={sp.simplify(Adot49_rad)}；卡面混合={sp.simplify(Adot49_card)}',
       '-37π/10',
       sp.simplify(Adot49_card+37*sp.pi/10) == 0,
       f'卡面混合模型可自洽到 -37π/10，但内外径折半口径不一致；定稿直径口径 {sp.simplify(Adot49_dia)}，半径口径 {sp.simplify(Adot49_rad)}')
Adot49v = 2*sp.pi*4*sp.Rational(1,10)
record('q3649-var', 'Ȧ=0.8π', '0.8π', sp.simplify(Adot49v-sp.Rational(4,5)*sp.pi) == 0,
       f'Ȧ={sp.simplify(Adot49v)}')

# ---------- q3650  圆锥熔体 ----------
hdot50 = 9*(-2)/(sp.pi*36)
record('q3650', 'ḣ=-1/(2π) cm/min', '-1/(2π)',
       sp.simplify(hdot50+1/(2*sp.pi)) == 0, f'ḣ={hdot50}')
hdot50v = 9*(-2)/(sp.pi*12**2)
record('q3650-var', 'ḣ=-1/(8π)', '-1/(8π)',
       sp.simplify(hdot50v+1/(8*sp.pi)) == 0, f'ḣ={hdot50v}')

# ---------- 汇总 ----------
print('\n===== 汇总 =====')
chk = [r for r in results if r[3] == 'CHECK']
print(f'总记录 {len(results)}，CHECK {len(chk)}')
for r in chk:
    print('CHECK:', r[0], r[1], '| 卡面:', r[2])
