# -*- coding: utf-8 -*-
# 阶段二核验 q3451–q3490 复算脚本（手算 + sympy 符号展开 + mpmath 采样）
# 只做核验，不改原稿。运行: python3 calc-3451-3490.py
import sympy as sp
import mpmath as mp

mp.mp.dps = 25
x, h, t = sp.symbols('x h t')

def num_quotient(fn, x0, side, eps=1e-5):
    u = x0 + (eps if side == '+' else -eps)
    return float((fn(u) - fn(x0)) / (u - x0))

print('=' * 70)
print('q3451  f=|x-1| e^x, 折点 x=1')
f = lambda u: abs(u - 1) * mp.e ** u
print('  左差商', num_quotient(f, 1, '-'), ' 右差商', num_quotient(f, 1, '+'),
      ' 卡值 -e / e =', -mp.e, mp.e)

print('=' * 70)
print('q3452  ln(1+2x)/x (x>0); ax+b (x<=0), 可导反参')
print('  连续极限', sp.limit(sp.log(1 + 2 * x) / x, x, 0))
print('  展开', sp.series(sp.log(1 + 2 * x) / x, x, 0, 3))
print('  卡值 b=2, a=-2')

print('=' * 70)
print('q3453  f=x|x-2|, 折点 x=2')
f = lambda u: u * abs(u - 2)
print('  左', num_quotient(f, 2, '-'), ' 右', num_quotient(f, 2, '+'), ' 卡值 -2 / 2')

print('=' * 70)
print('q3454  (sqrt(1+x)-1)/x 补 k, f\'(0)')
print('  连续极限', sp.limit((sp.sqrt(1 + x) - 1) / x, x, 0))
print('  展开', sp.series((sp.sqrt(1 + x) - 1) / x, x, 0, 3))
print('  卡值 k=1/2, f\'(0)=-1/8')

print('=' * 70)
print('q3455  f=(sin x)|cos x|, 折点 pi/2')
f = lambda u: mp.sin(u) * abs(mp.cos(u))
a = mp.pi / 2
print('  左', num_quotient(f, a, '-'), ' 右', num_quotient(f, a, '+'), ' 卡值 -1 / 1')
print('  --- 变式 f=|sin x| cos x 在 0 ---')
g = lambda u: abs(mp.sin(u)) * mp.cos(u)
print('  右差商(+)', num_quotient(g, 0, '+'), ' 左差商(-)', num_quotient(g, 0, '-'))
print('  卡 var-ans: 存在 f\'(0)=1 ；复算: 左 -1 右 +1，不可导')

print('=' * 70)
print('q3456  f=e^x cos(1/x), 0 补零；差商两列点')
for n in (10, 100, 1000):
    u1 = 1 / (2 * n * mp.pi)
    u2 = 1 / ((2 * n + 1) * mp.pi)
    q1 = float(mp.e**u1 * mp.cos(1 / u1) / u1)
    q2 = float(mp.e**u2 * mp.cos(1 / u2) / u2)
    print(f'  n={n}: 正峰列商 {q1:.3f}, 负谷列商 {q2:.3f}')

print('=' * 70)
print('q3457  f=arcsin(sqrt x), 右导数')
print('  等价主部 arcsin t~t, 商 ~ 1/sqrt x -> +inf; 卡值 不存在(+inf)')
print('  变式 arcsin x 差商', num_quotient(lambda u: mp.asin(u), 0, '+'))

print('=' * 70)
print('q3458  f=x^3 |ln|x||, 差商 x^2 |ln|x||')
for e in (1e-3, 1e-5, 1e-7):
    print(f'  x={e}: 差商 {float(e**2 * abs(mp.log(e))):.6g}')

print('=' * 70)
print('q3459  f=(1-cos x)/x 补 0, 差商 (1-cos x)/x^2')
print('  sympy 极限', sp.limit((1 - sp.cos(x)) / x**2, x, 0), ' 卡值 1/2')
print('  变式 (e^x-1)/x 展开', sp.series((sp.exp(x) - 1) / x, x, 0, 3))

print('=' * 70)
print('q3460  f=|sin x| sign(x) ≡ sin x, 差商')
g = lambda u: abs(mp.sin(u)) * (1 if u > 0 else -1)
print('  右', num_quotient(g, 0, '+'), ' 左', num_quotient(g, 0, '-'), ' 卡值 1')

print('=' * 70)
print('q3461  f=³√x sin²x, 净阶次 1/3+2-1=4/3')
print('  变式 ³√x sin x 净阶次 1/3+1-1=1/3 >0, 采样:')
g = lambda u: mp.sign(u) * mp.cbrt(abs(u)) * mp.sin(u)
for e in (1e-2, 1e-4):
    print(f'  x={e}: 商 {num_quotient(g, 0, "+" if e>0 else "-"):.6g}')

print('=' * 70)
print('q3462  (tan x-x)/x^3 补 a')
print('  tan 展开', sp.series(sp.tan(x), x, 0, 6))
print('  分式展开', sp.series((sp.tan(x) - x) / x**3, x, 0, 4))
print('  卡值 a=1/3, f\'(0)=0; 变式 (sin x-x)/x^3 展开',
      sp.series((sp.sin(x) - x) / x**3, x, 0, 4))

print('=' * 70)
print('q3463  f=x^2 [x], 折点 1')
f = lambda u: u**2 * mp.floor(u)
print('  右差商', num_quotient(f, 1, '+'), ' 左差商(负分母趋0-)',
      float((f(1 - 1e-5) - f(1)) / (-1e-5)), ' 卡值 左 +inf, 右 2')

print('=' * 70)
print('q3464  e^{-1/x^2} sin(1/x), 差商上界 t e^{-t^2}')
for t_ in (5, 10, 20):
    print(f'  t={t_}: t e^(-t^2)={float(t_*mp.e**(-t_**2)):.6g}')
print('  变式 e^{-1/|x|} sin(1/x), 上界 t e^{-t}:',
      [f'{t_} e^-t={float(t_*mp.e**(-t_)):.6g}' for t_ in (5, 10, 20)])

print('=' * 70)
print('q3465  左支 f≡0, f\'_-(0)=0; 变式右差商 x e^{1/x}')
for e in (1e-2, 1e-3):
    print(f'  x={e}: x e^{{1/x}}={float(e*mp.e**(1/e)):.6g}')

print('=' * 70)
print('q3466  f=|arctan x|')
g = lambda u: abs(mp.atan(u))
print('  右', num_quotient(g, 0, '+'), ' 左', num_quotient(g, 0, '-'), ' 卡值 -1 / 1')

print('=' * 70)
print('q3467  f=sin x/x, 级数与高阶导数')
ser = sp.series(sp.sin(x) / x, x, 0, 8)
print('  ', ser)
for k in range(3):
    print(f'  f^({2*k})(0)=(-1)^{k}/(2k+1)={(-1)**k/(2*k+1)}')
print('  变式 (1-cos x)/x^2 级数', sp.series((1 - sp.cos(x)) / x**2, x, 0, 6))

print('=' * 70)
print('q3468  f=x^3 sign(x)')
g = lambda u: u**3 * (1 if u > 0 else -1)
print('  右', num_quotient(g, 0, '+'), ' 左', num_quotient(g, 0, '-'), ' 卡值 0')

print('=' * 70)
print('q3469  f=[x] sin(pi x), 左导数 (n-1)(-1)^n pi')
for n in (1, 2, 3):
    f = lambda u, n=n: mp.floor(u) * mp.sin(mp.pi * u)
    exp = (n - 1) * (-1) ** n * mp.pi
    print(f'  n={n}: 公式值 {float(exp):.6f}, 右邻域采样 {num_quotient(f, n, "+"):.6f}')
print('  变式 f\'_+(n)=n(-1)^n pi')

print('=' * 70)
print('q3470  ln(1+x)-x / ax^2+bx, f\"(0) 存在')
print('  右支一阶', sp.limit((sp.log(1 + x) - x) / x, x, 0))
g = sp.log(1 + x) - x
print('  右支二阶 g\"(0)=', sp.diff(sp.diff(g, x), x).subs(x, 0))
print('  卡值 b=0, a=-1/2; 变式 e^x-1-x, g\"(0)=',
      sp.diff(sp.diff(sp.exp(x) - 1 - x, x), x).subs(x, 0), ' -> a=1/2')

print('=' * 70)
print('q3471  |x^2-4x+3|, 折点 1 与 3')
p = sp.Poly(x**2 - 4 * x + 3, x)
print('  因式', sp.factor(x**2 - 4 * x + 3))
f = lambda u: abs(u**2 - 4 * u + 3)
print('  x=1: 左', num_quotient(f, 1, '-'), ' 右', num_quotient(f, 1, '+'))
print('  x=3: 左', num_quotient(f, 3, '-'), ' 右', num_quotient(f, 3, '+'))

print('=' * 70)
print('q3472  (e^x-1-x)/x^2, 求 k 使 f\'(0)=0')
print('  展开', sp.series((sp.exp(x) - 1 - x) / x**2, x, 0, 4))
print('  连续极限 k=1/2; 此时 f\'(0)=1/6 !=0; 卡值 不存在这样的 k')

print('=' * 70)
print('q3473  f=x|x-1||x-2|')
f = lambda u: u * abs(u - 1) * abs(u - 2)
print('  x=1: 左', num_quotient(f, 1, '-'), ' 右', num_quotient(f, 1, '+'))
print('  x=2: 左', num_quotient(f, 2, '-'), ' 右', num_quotient(f, 2, '+'))

print('=' * 70)
print('q3474  f=cos sqrt|x|')
f = lambda u: mp.cos(mp.sqrt(abs(u)))
print('  右差商', num_quotient(f, 0, '+'), ' 左差商', num_quotient(f, 0, '-'),
      ' 卡值 左 +1/2 右 -1/2')

print('=' * 70)
print('q3475  arcsin x/x 补 1')
print('  展开', sp.series(sp.asin(x) / x, x, 0, 4), ' 无一次项 -> f\'(0)=0')

print('=' * 70)
print('q3476  |x|^3 sgn(x) ≡ x^3, f\"(0)=0')
print('  变式 x^2 sgn(x): 右侧 2x, 左侧 -2x; 二阶左右 +2 / -2 不存在')

print('=' * 70)
print('q3477  e^{-1/|x|} 补 0, 差商上界 t e^{-t}')
for t_ in (5, 10, 20):
    print(f'  t={t_}: {float(t_*mp.e**(-t_)):.6g}')

print('=' * 70)
print('q3478  x^2 sin(1/|x|), 差商 x sin(1/|x|) 夹逼 0')

print('=' * 70)
print('q3479/88  可导 f 乘 |x-a| 在 a 可导 iff f(a)=0; 双向差商')
print('  f(a)!=0: 左 -f(a), 右 +f(a); f(a)=0: 商 ~ f\'(a)|x-a| ->0')

print('=' * 70)
print('q3480  f(0)=1 非零, g 连续不可导 -> fg 不可导（反证: 商可导）')

print('=' * 70)
print('q3481/85/89  (x-c)^m |x-c| 合成幂次与二阶差商')
for m, c in ((3, 2), (2, 1), (4, -1), (2, 2), (3, -1)):
    f = lambda u, m=m, c=c: (u - c)**m * abs(u - c)
    r = num_quotient(f, c, '+')
    print(f'  m={m}, c={c}: 一阶右商 {r:.6g}')

print('=' * 70)
print('q3483  f=x|x-3|')
f = lambda u: u * abs(u - 3)
print('  左', num_quotient(f, 3, '-'), ' 右', num_quotient(f, 3, '+'),
      ' 一阶不存在 -> 二阶不存在')

print('=' * 70)
print('q3484  [f(x)]^2 sgn(x) 在 0 可导 iff f(0)=0')
print('  f(0)!=0: 左右跳跃 ±f(0)^2; f(0)=0: 商 ~ f\'(0)^2 x ->0')

print('=' * 70)
print('q3486  h(x)=f(|x|), 右 f\'(0), 左 -f\'(0); 相等 iff f\'(0)=0')

print('=' * 70)
print('q3487  |x|^k 可导阶次: 偶整数全阶; 奇整数 ≤k-1; 非整数 ≤floor(k)')
for k in (1, 2, 3, sp.Rational(3, 2), sp.Rational(5, 2)):
    print(f'  k={k}')

print('=' * 70)
print('q3490  f(0)!=0 连续, 邻域同号 |f|=s f, 可导性等价')
print('  变式 f(0)=2, f\'(0)=-3 -> (|f|)\'(0)=-3')
