# -*- coding: utf-8 -*-
"""
阶段二核验复算脚本：q3531–q3570（跨《无穷小》200题 与 01-tixing-6000 两册）
方法：手算泰勒展开 + sympy 符号求导 + mpmath 数值采样。
运行：python3 calc-3531-3570.py
说明：本脚本只做复算核验，不回写任何原稿；卡片 answer 栏为唯一判定出口。
"""

import mpmath as mp
import sympy as sp

mp.mp.dps = 30
x = mp.mpf("0.01")

print("=" * 70)
print("一、《无穷小》册（q3531–q3547，qsrc P1141–P1144）")
print("=" * 70)

# q3531 积分相减定阶 (e^t-1)/t - x
f3531 = lambda xi: mp.quad(lambda t: (mp.e ** t - 1) / t, [0, xi]) - xi
print("q3531 t(x)/x^2 ≈", mp.nstr(f3531(x) / x ** 2, 6), " 卡片 u=2；变式 g=∫sin t/t dt-x，n=3")

# q3532 (ln(1+x^2)-x^2)/x^4
print("q3532 极限 ≈", mp.nstr((mp.log(1 + x ** 2) - x ** 2) / x ** 4, 6), " 卡片 O=-1/2；变式 (e^{x^2}-1-x^2)/x^4=1/2")

# q3533 cos(sin x)-cos x
v3533 = mp.cos(mp.sin(x)) - mp.cos(x)
print("q3533 v/x^4 ≈", mp.nstr(v3533 / x ** 4, 6), " v/x^3 ≈", mp.nstr(v3533 / x ** 3, 4), " 卡片 w=3（四阶）")

# q3534 (tan(sin x)-sin(tan x))/x^7
print("q3534 P ≈", mp.nstr((mp.tan(mp.sin(x)) - mp.sin(mp.tan(x))) / x ** 7, 6), " 卡片 P=1/30；变式反向=-1/30")

# q3535 ∫arcsin t/t dt - x
g3535 = mp.quad(lambda t: mp.asin(t) / t, [0, x]) - x
print("q3535 g/x^3 ≈", mp.nstr(g3535 / x ** 3, 6), " 卡片 n=3；变式 arctan t/t 型 n=3")

# q3536 (ln(1+tan x)-sin x)/x^2
print("q3536 Q ≈", mp.nstr((mp.log(1 + mp.tan(x)) - mp.sin(x)) / x ** 2, 6), " 卡片 Q=-1/2")

# q3537 e^{cos x}-e
p3537 = mp.e ** (mp.cos(x)) - mp.e
print("q3537 p/x^2 ≈", mp.nstr(p3537 / x ** 2, 6), "（=-e/2≈-1.35914） p/x ≈", mp.nstr(p3537 / x, 4), " 卡片 q=1；变式极限 -e/2")

# q3538 (arcsin(tan x)-arctan(sin x))/x^3
print("q3538 R ≈", mp.nstr((mp.asin(mp.tan(x)) - mp.atan(mp.sin(x))) / x ** 3, 6), " 卡片 R=1；变式反向=-1")

# q3539 ∫ln(1+t^3)/t^2 dt
r3539 = mp.quad(lambda t: mp.log(1 + t ** 3) / t ** 2, [0, x])
print("q3539 r/x^2 ≈", mp.nstr(r3539 / x ** 2, 6), " 卡片 s=2；变式 ln(1+t^2)/t 型 s=2")

# q3540 (sin(x^2)-x^2 cos(x^2))/x^6
print("q3540 T ≈", mp.nstr((mp.sin(x ** 2) - x ** 2 * mp.cos(x ** 2)) / x ** 6, 6), " 卡片 T=1/3；变式 x^3 型 1/3")

# q3541 ln(1+sqrt(1+x)-1)
print("q3541 t/x ≈", mp.nstr(mp.log(1 + mp.sqrt(1 + x) - 1) / x, 6), " 卡片 u=1；变式 e^{sqrt(1+x)-1}-1 型 u=1")

# q3542 (e^{sin x}-e^{tan x})/x^3
print("q3542 U ≈", mp.nstr((mp.e ** mp.sin(x) - mp.e ** mp.tan(x)) / x ** 3, 6), " 卡片 U=-1/2；变式反向=1/2")

# q3543 排序题阶数
A = mp.log(1 + x ** 2) - mp.sin(x ** 2)
B = mp.e ** x ** 2 - mp.cos(x)
C = mp.quad(lambda t: mp.cos(t) - 1, [0, x])
D = mp.tan(x) - x - x ** 3 / 3
print("q3543 阶数 A:4 B:2 C:3 D:5 → 最高 D，卡片 (D)；变式 ln(1+x)-sin x 与 1-cos x 同为二阶")
for nm, val, o in [("A", A, 4), ("B", B, 2), ("C", C, 3), ("D", D, 5)]:
    print("      ", nm, "主部系数 ≈", mp.nstr(val / x ** o, 5))

# q3544 夹逼定 n
first = (x - mp.sin(x)) * mp.log(1 + x)
e2 = mp.e ** x ** 2 - 1
third = 1 / x ** 2 * mp.quad(lambda t: 1 - mp.cos(t) ** 2, [0, x])
print("q3544 一阶量/x^4 ≈", mp.nstr(first / x ** 4, 5), " 二阶量/x^2 ≈", mp.nstr(e2 / x ** 2, 5),
      " 三阶量(n=2)/x ≈", mp.nstr(third / x, 5), " 卡片 n=2；变式 m=2")

# q3545 等价定 a
L = (1 + mp.mpf("2/3") * x ** 4) ** sp.Rational(1, 2) - 1
R = (1 + x) ** (mp.tan(x) - x) - 1
print("q3545 L/x^4 ≈", mp.nstr(L / x ** 4, 5), " R/x^4 ≈", mp.nstr(R / x ** 4, 5), " 卡片 a=2/3；变式指数 1/3 型 a=1")

# q3546 ∫sin t/t dt - x ~ a x^b
G = mp.quad(lambda t: mp.sin(t) / t, [0, x]) - x
print("q3546 G/x^3 ≈", mp.nstr(G / x ** 3, 6), " 卡片 a=-1/18, b=3；变式 arcsin 型 a=1/18, b=3")

# q3547 排序题阶数
A7 = mp.log(1 + x ** 4) - x ** 4
B7 = mp.e ** x ** 2 - 1 - x ** 2
C7 = mp.quad(lambda t: mp.sin(t ** 2), [0, x])
D7 = mp.tan(x) - x - x ** 3 / 3
print("q3547 阶数 A:8 B:4 C:3 D:5 → 最高 A，卡片 (A)；变式 e^{x^4}-1-x^4 为八阶")
for nm, val, o in [("A", A7, 8), ("B", B7, 4), ("C", C7, 3), ("D", D7, 5)]:
    print("      ", nm, "主部系数 ≈", mp.nstr(val / x ** o, 5))

print()
print("=" * 70)
print("二、01-tixing-6000 册（q3548–q3570，qsrc P66–P67）")
print("=" * 70)

xx, tt, yy = sp.symbols("x t y", real=True)

# q3548 f=|x-4|^3，f''(4)：双侧二阶导在 4 处均趋于 0（主答案）；变式 |h|^2=h^2
h = sp.symbols("h")
print("q3548 主答案 f''(4)=0（右 6h→0，左 -6h→0）；变式复算：|h|^2 =", sp.simplify(sp.Abs(h) ** 2),
      " ⇒ f=(x-1)^2，f''(1)=2 存在（卡 var-ans 作不存在，判 fail）")

# q3549 商式可导性：反例 f=x^2,g=|x| → |x| 可导；f=x,g=|x| → sign x 不可导
print("q3549 不一定：f=x^2/g=|x| 商=|x| 可导(导0)；f=x/g=|x| 商=sign x 不可导；变式 x^2/√|x|=|x|^{3/2} 导 0")

# q3550 f=(x-5)^2|x-5|，三阶导双侧 ±6
print("q3550 f^(3)(5) 不存在：左 -6，右 +6；变式 (x-2)|x-2| 的 f''(2) 不存在（±2）")

# q3551 f=|x^2-1|，f'(1) 双侧 ±2
print("q3551 f'(1) 不存在：左 -2，右 +2；变式 |x^2-4| 在 2 处 ±4，不存在")

# q3552 主答案不一定；变式复算：f=-x^2，[f(0)]=[0]=0，邻域 [f]=-1，间断不可导
print("q3552 主答案不一定；变式复算：g(f(0))=[0]=0，x≠0 邻域 f∈(-1,0)，[f]=-1，极限 -1 ≠ 0，不可导（卡 var-ans 作可导 0，判 fail）")

# q3553 (f∘g)'(0)=0
print("q3553 (f∘g)(x)=|x|^3 sin(1/|x|)，差商绝对值 ≤ |x|^2 → 0，导数 0；变式 x sin(1/x) 差商振荡，f'(0) 不存在")

# q3554 |x||x-2| 折点
print("q3554 f'(0) 不存在(左-2 右+2)；f'(2) 不存在(左-2 右+2)；变式 |x+1||x-1| 两点均不可导")

# q3555 一般幂次 |x-a|
print("q3555 k≤n 时 f^(k)(a)=0 存在；k=n+1 双侧 ±(n+1)! 不存在；k>n+1 亦不存在；变式 n=3 四阶、五阶均不存在")

# q3556 f(0)=1, g=sign x
print("q3556 不可导：右差商→1，左→-1；变式 f(0)=2,g=|x| 不可导（±2）")

# q3557 sqrt|x| 右导数
print("q3557 f'_+(0) 不存在：1/√x→+∞；变式 |x|^{3/2} 导 0")

# q3558 |x^3-8| 在 2 处
print("q3558 f'(2) 不存在：左 -12，右 +12；变式 |x^3+1| 在 -1 处 ±3，不存在")

# q3559 充要条件
print("q3559 充要条件：f(0)=0 时差商被压到 0；f(0)≠0 双侧 ±f(0)；变式 g=|x| 同结论")

# q3560 (x+2)^5|x+2| 四阶导
print("q3560 n=5，k=4≤5 ⇒ f^(4)(-2)=0；变式六阶为临界阶，±6! 不存在")

# q3561 |x|cos x 在 0 处
print("q3561 f'(0) 不存在：左 -1，右 +1；变式 |x|sin x 导 0")

# q3562 |x-1||x-3|
print("q3562 f'(1) 不存在(左-2 右+2)；f'(3) 不存在(左-2 右+2)；变式 |x-2||x-4| 在 2 处左-2 右+2")

# q3563 y=ln(sin sqrt(x^2+1))
u = sp.sqrt(xx ** 2 + 1)
y63 = sp.log(sp.sin(u))
print("q3563 dy/dx =", sp.simplify(sp.diff(y63, xx)), " 卡片 x/sqrt(x^2+1)·cot sqrt(x^2+1)")

# q3564 z=e^{xy}+cos(xy), x=t^2, y=ln t
xy = tt ** 2 * sp.log(tt)
zz = sp.exp(xy) + sp.cos(xy)
print("q3564 dz/dt =", sp.simplify(sp.diff(zz, tt)))

# q3565 y=arctan((1+x)/(1-x))
y65 = sp.atan((1 + xx) / (1 - xx))
print("q3565 y' =", sp.simplify(sp.diff(y65, xx)), " y'' =", sp.simplify(sp.diff(y65, xx, 2)))

# q3566 u=f(xy, x^2+y^2)，全微分（结构核验）
print("q3566 du=(y f1'+2x f2')dx+(x f1'+2y f2')dy；变式 f(x+y,x-y)：(f1'+f2')dx+(f1'-f2')dy")

# q3567 y=x^{x^x}
y67 = sp.Pow(xx, sp.Pow(xx, xx))
print("q3567 y' =", sp.simplify(sp.diff(y67, xx)))

# q3568 x^y=y^x 隐函数求导
F8 = xx ** yy - yy ** xx
dy8 = -sp.diff(F8, xx) / sp.diff(F8, yy)
print("q3568 dy/dx =", sp.simplify(dy8), " 卡片 y(x ln y-y)/[x(y ln x-x)]")

# q3569 参数方程
xt = tt + sp.atan(tt)
yt = tt - sp.log(1 + tt ** 2)
dx, dy = sp.diff(xt, tt), sp.diff(yt, tt)
yp = dy / dx
ypp = sp.diff(yp, tt) / dx
print("q3569 d^2y/dx^2 =", sp.simplify(ypp))

# q3570 y=sin(x+y)
F70 = yy - sp.sin(xx + yy)
dy70 = -sp.diff(F70, xx) / sp.diff(F70, yy)
print("q3570 dy/dx =", sp.simplify(dy70), " 卡片 cos(x+y)/(1-cos(x+y))")

print()
print("复算完成。判定出口：卡片 answer 栏；本片内未发现近似全等副本。")
