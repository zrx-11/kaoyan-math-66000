# -*- coding: utf-8 -*-
"""阶段二补记：把 q3485 由 pass 改判 fail（变式侧值 ±1 → ±2）。仅改台账一行。"""
import csv
from collections import Counter

p = "work/drafts/verify/unit-3451-3490.csv"
rows = list(csv.reader(open(p, newline="")))

recalc = "主题 f''(1)=0 正确（t²|t|=±t³，二阶差商 3t/−3t→0）；变式 f=(x−1)|x−1|：f''(1) 不存在，左二阶 −2、右二阶 +2"
basis = (
    "三段式——卡当前值：主题 answer「f''(1)=0」正确；变式 var-ans「不存在；双侧 ±t²，"
    "f'(1)=0，二阶差商左右为 +1、−1」。"
    "→ 复算值：变式令 t=x−1，t>0 段 f=t²、t<0 段 f=−t²，"
    "f'(1)=0，两侧导函数 f'=2t（右）/−2t（左），二阶差商 [f'(h)−f'(0)]/h=+2（右）、−2（左），"
    "左右不等故 f''(1) 不存在；「不存在」结论成立，侧值 ±1 错误。"
    "→ 依据：±1 系二次项系数 f(h)/h²"
    "（h=±1e-3 采样 f/h²=±1.000），并非二阶导数；h=+1e-3 二阶差商 2.0000，h=−1e-3 为 −2.0000；"
    "本条变式与 q3492 变式逐字全等（同一道 (x−1)|x−1| 求 f''(1)），q3492 已判 fail。"
)
action = (
    "var-ans 侧值 ±1 改为 ±2（右 +2、左 −2），保留「不存在、二阶折点」结论；"
    "本条变式与 q3492 变式逐字重复，合并层已挂账，建议换一条变式"
)
position = "qsrc P65＝页脚书50页，题型三 题7（本页共13题，题3–15）"

hit = False
for r in rows[1:]:
    if r[0] == "3485":
        r[2] = "fail"
        r[3] = recalc
        r[4] = basis
        r[5] = position
        r[6] = action
        hit = True
        break

assert hit, "q3485 row not found"

with open(p, "w", newline="") as f:
    w = csv.writer(f, quoting=csv.QUOTE_ALL)
    w.writerows(rows)

print("rows:", len(rows) - 1)
print(Counter(r[2] for r in rows[1:]))
