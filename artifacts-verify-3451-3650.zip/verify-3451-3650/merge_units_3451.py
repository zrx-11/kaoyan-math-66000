# -*- coding: utf-8 -*-
"""合并 q3451–q3650 的 5 个分片 → verify-3451-3650.csv + rerecord-3451-3650.csv。

整合层修正（主控在合并层做，分片看不到跨片关系；不改分片的复算值）：
  A. 变式层逐字/近似全等（跨片，只有合并层能发现）：
     q3485 ≡ q3492（逐字全等，同为 (x−1)|x−1| 求 f″(1)，答案同为 ±1 错值）；
     q3519 ≡ q3539（逐字全等，∫₀^x ln(1+t²)/t dt 与 x^s 同阶，s=2）；
     q3478 ≈ q3553（仅差绝对值 x sin(1/|x|) vs x sin(1/x)）；
     q3633 ≡ q3647（梯 10m/6m/外滑0.5，答案 −3/8）；
     q3550 变式与 q3485/q3492 变式同族（仅平移），是三条里唯一算对侧值的一条。
  B. 卡级 dup：本段 0 条（200 张题干归一化后无全等）。
  C. 主控独立复核：q3485（±1 应为 ±2）、q3649（−21π/20 应为 −21π/10）、
     q3623（顶端达3m → −8/3）、q3632（斜距 −√5）、q3625（ḣ=2/π）、q3612（−6x sin x）、
     q3571（页图 v=x²+y）均由主控复算或读页图确认，与分片一致。
"""
import csv, os, datetime, collections

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
D = os.path.join(ROOT, "work/drafts/verify")
UNITS = ["unit-3451-3490.csv", "unit-3491-3530.csv", "unit-3531-3570.csv",
         "unit-3571-3610.csv", "unit-3611-3650.csv"]
HDR = ["q", "page", "verdict", "复算值", "依据", "页码与页内位置", "建议动作"]
OKV = {"pass", "fail", "fixed", "skip", "dup"}

NOTE = {
 "3485": "变式与 q3492 变式逐字全等（同为 (x−1)|x−1| 求 f″(1)，答案同为「±1」错值）；改 ±2 后建议直接换一条变式（换形如 (x−1)²|x−1| 或 x|x−1|）。",
 "3492": "变式与 q3485 变式逐字全等；保留 q3485 一份（其主问 f″=0 与本变式对照更清楚），改写本条变式。",
 "3519": "变式 ∫₀^x ln(1+t²)/t dt 与 q3539 变式逐字全等（仅函数名 r/p 不同，答案同为 s=2）；建议改本条为 ∫₀^x ln(1+t³)/t dt（→s=3）或 x^{1/2} 幂型。",
 "3539": "变式与 q3519 变式逐字全等；保留 q3519 一份，改写本条。",
 "3478": "变式 x sin(1/|x|) 与 q3553 变式 x sin(1/x) 仅差绝对值，答案同为「不存在」；建议保留本条（绝对值版更能考双侧），改写 q3553。",
 "3553": "变式与 q3478 变式仅差绝对值；建议改为 x² sin(1/x)（可导、f'(0)=0）以形成对照。",
 "3633": "变式（梯 10m、底离墙 6m、外滑 0.5，−3/8）与 q3647 变式同式；建议改本条的梯长或外滑速。",
 "3647": "变式与 q3633 变式同式；保留 q3633（其主问为顶下滑速率，与变式同型），本卡宜改考「中点速度」的变式。",
 "3550": "变式 (x−2)|x−2| 右 +2 / 左 −2，复核正确；与 q3485、q3492 变式同族（仅平移），三条里唯一侧值算对的一条，建议保留本卡变式。",
}

rows = []
for u in UNITS:
    with open(os.path.join(D, u), encoding="utf-8") as fh:
        rd = csv.DictReader(fh)
        assert rd.fieldnames == HDR, (u, rd.fieldnames)
        for r in rd:
            r["q"] = r["q"].strip().lstrip("qQ").strip()
            r["page"] = r["page"].strip()
            assert r["verdict"] in OKV, (u, r["q"], r["verdict"])
            rows.append(r)

assert len(rows) == 200, len(rows)
qs = [int(r["q"]) for r in rows]
assert sorted(qs) == list(range(3451, 3651)), "q 覆盖不全或重复"
assert len(set(qs)) == 200
for r in rows:
    assert r["q"].isdigit() and r["page"].isdigit(), ("q/page 非纯数字", r["q"], r["page"])
    if r["verdict"] == "pass":
        assert r["复算值"].strip(), ("pass 缺复算值", r["q"])
    if r["verdict"] in ("fail", "fixed"):
        ev = r["依据"]
        # fail 必须三段式（箭头或三标签）；fixed（书错卡对）允许「复算值/依据」双标签写法
        ok = ("→" in ev) or all(k in ev for k in ("卡当前值", "复算值", "依据"))
        if r["verdict"] == "fixed":
            ok = ok or ("复算值" in ev and "依据" in ev)
        assert ok, ("非三段式", r["q"])
    if r["q"] in NOTE:
        r["建议动作"] = "；".join([x for x in [r["建议动作"].strip(), NOTE[r["q"]]] if x])

rows.sort(key=lambda r: int(r["q"]))
with open(os.path.join(D, "verify-3451-3650.csv"), "w", encoding="utf-8", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=HDR)
    w.writeheader()
    w.writerows(rows)

now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
rr = [{"q": str(int(r["q"])), "page": r["page"], "verdict": "fixed",
       "note": (r["复算值"] + "｜" + r["建议动作"])[:230], "time": now}
      for r in rows if r["verdict"] == "fail"]
with open(os.path.join(D, "rerecord-3451-3650.csv"), "w", encoding="utf-8", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=["q", "page", "verdict", "note", "time"])
    w.writeheader()
    w.writerows(rr)

c = collections.Counter(r["verdict"] for r in rows)
print("rows", len(rows), dict(c))
print("fail:", [r["q"] for r in rows if r["verdict"] == "fail"])
print("fixed:", [r["q"] for r in rows if r["verdict"] == "fixed"])
print("skip:", [r["q"] for r in rows if r["verdict"] == "skip"])
print("dup:", [r["q"] for r in rows if r["verdict"] == "dup"])
print("pages", sorted({int(r["page"]) for r in rows})[:5], "…", sorted({int(r["page"]) for r in rows})[-5:])
print("ALL_CHECKS_OK")
