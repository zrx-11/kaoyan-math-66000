# -*- coding: utf-8 -*-
# 阶段二核验 q3491–q3530 独立复算脚本
# 方法：sympy 符号展开（泰勒/二项式/级数）+ mpmath 数值采样双侧核验
# 仅复算主题与变式，不改原稿。

import sympy as sp
import mpmath as mp

mp.dps = 25
x, t, h = sp.symbols('x t h')

def order_and_coeff(expr, var=x, tol=1e-12):
    """返回表达式在 var→0 处首个非零泰勒项的阶与系数。"""
    ser = sp.series(expr, var, 0, 12).removeO()
    poly = sp.Poly(ser, var)
    if poly.is_zero:
        return None, None
    terms = sorted(poly.terms(), key=lambda z: z[0][0])
    return terms[0][0][0], sp.simplify(terms[0][1])

def num_limit(f, val=0.1, side=1):
    """mpmath 数值采样，val→0 比值。"""
    out = []
    for d in (0.2, 0.1, 0.05, 0.02):
        z = side * d
        try:
            out.append(float(f(z)))
        except ZeroDivisionError:
            out.append(float('nan'))
    return out

print("=" * 70)
print("【01-tixing-6000 分册】q3491–q3493")
print("=" * 70)

# ---- q3491: f(x)=x^2 sgn(cos pi x), 求 f'(n); 变式 f=x sgn(cos pi x) ----
print("\n[q3491] f=x^2 sgn(cos pi x)")
for n in (0, 1, 2, 3):
    # 邻域内 cos(pi x) 与 cos(pi n)=(-1)^n 同号，f(x)=(-1)^n x^2
    deriv = sp.diff((-1) ** n * x ** 2, x).subs(x, n)
    print(f"  n={n}: 公式 2n(-1)^n = {2*n*(-1)**n}, 邻域多项式导数 = {deriv}")
# 变式: f=x sgn(cos pi x) -> 邻域 f=(-1)^n x, 导数 (-1)^n
print("  变式 f=x sgn(cos pi x): 邻域导数 =", [(-1) ** n for n in (0, 1, 2)])

# ---- q3492: 分段二次; f''(1) ----
print("\n[q3492] f=(x-1)^2 (x>=1), -(x-1)^2 (x<1)")
u = sp.symbols('u')
fR, fL = u ** 2, -u ** 2
f1R, f1L = sp.diff(fR, u), sp.diff(fL, u)
d2R = sp.limit((f1R.subs(u, h) - 0) / h, h, 0, '+')
d2L = sp.limit((f1L.subs(u, h) - 0) / h, h, 0, '-')
print(f"  右二阶导数 = {d2R}, 左二阶导数 = {d2L}  => f''(1) 不存在" )
# 一阶差商
d1R = sp.limit(fR.subs(u, h) / h, h, 0, '+')
d1L = sp.limit(fL.subs(u, h) / h, h, 0, '-')
print(f"  右一阶 = {d1R}, 左一阶 = {d1L} => f'(1)=0")
# 变式 f=(x-1)|x-1| = u|u|; 右 u^2, 左 -u^2
print("  变式 f=u|u|: 右段 u^2, 左段 -u^2; 右二阶 =",
      sp.diff(u ** 2, u, 2), "左二阶 =", sp.diff(-u ** 2, u, 2))
# 数值采样变式二阶（按一阶导函数差商: g'(h)/h）
def gprime(z):
    return 2*z if z > 0 else -2*z
for d in (0.1, 0.01):
    print(f"    h=+{d}: g'(h)/h = {gprime(d)/d:.4f}; h=-{d}: g'(h)/h = {gprime(-d)/(-d):.4f}")

# ---- q3493: |f| 在零点非零斜率处不可导 ----
print("\n[q3493] g=|f|, f(a)=0, f'(a)=c≠0")
c = sp.symbols('c')
# f(x)=c(x-a)+o(x-a); 右差商 |c|, 左差商 -|c|
print("  右导数 = |c|, 左导数 = -|c|; 变式 c=2: 右 2, 左 -2")

print("\n" + "=" * 70)
print("【《无穷小》200题】q3494–q3530")
print("=" * 70)

# ---- q3494: sqrt(1+x)-sqrt(1-x)-x ----
print("\n[q3494] f=√(1+x)-√(1-x)-x")
f = sp.sqrt(1 + x) - sp.sqrt(1 - x) - x
deg, coef = order_and_coeff(f)
print(f"  主部: x^{deg} * {coef}")
print(f"  数值 x=0.01: f={float(f.subs(x, 0.01)):.6e}, x^3/8={0.01**3/8:.6e}")
# 变式 √(1+x^2)-√(1-x^2)-x^2
fv = sp.sqrt(1 + x ** 2) - sp.sqrt(1 - x ** 2) - x ** 2
dv, cv = order_and_coeff(fv)
print(f"  变式主部: x^{dv} * {cv}")

# ---- q3495: tan x - sin x ----
print("\n[q3495] g=tan x - sin x")
g = sp.tan(x) - sp.sin(x)
deg, coef = order_and_coeff(g)
print(f"  主部: x^{deg} * {coef}")
print(f"  数值 x=0.05: g/x^3={float(g.subs(x,0.05)/0.05**3):.6f} -> 1/2={0.5}")
print("  变式 (tan x-sin x)/x^3 ->", sp.limit(g/x**3, x, 0))

# ---- q3496: e^x -1 -x -x^2/2 -x^3/6 ----
print("\n[q3496] h=e^x-1-x-x^2/2-x^3/6")
h = sp.exp(x) - 1 - x - x**2/2 - x**3/6
deg, coef = order_and_coeff(h)
print(f"  主部: x^{deg} * {coef}; h=o(x^m) => m<4; ln(1+x^2)~x^2 => m>2; m=3")
# 变式 cos x -1 + x^2/2
hv = sp.cos(x) - 1 + x**2/2
dv, cv = order_and_coeff(hv)
print(f"  变式主部: x^{dv} * {cv}; 同样夹 2<m<4 => m=3")

# ---- q3497: ∫(e^{t^2}-1)dt ----
print("\n[q3497] p=∫0^x (e^{t^2}-1)dt")
p = sp.integrate(sp.exp(t**2) - 1, (t, 0, x))
deg, coef = order_and_coeff(p)
print(f"  主部: x^{deg} * {coef}")
pv = sp.integrate(sp.log(1 + t**2), (t, 0, x))
dv, cv = order_and_coeff(pv)
print(f"  变式 ∫ln(1+t^2)dt 主部: x^{dv} * {cv}")

# ---- q3498: ln(1+x)-x ----
print("\n[q3498] q=ln(1+x)-x")
q = sp.log(1 + x) - x
deg, coef = order_and_coeff(q)
print(f"  主部: x^{deg} * {coef}; q=o(x^r) => r<2, 整数最大 r=1")
qv = sp.log(1 + x) - x + x**2/2
dv, cv = order_and_coeff(qv)
print(f"  变式主部: x^{dv} * {cv}; r<3, 最大 r=2")

# ---- q3499: sin x - x ----
print("\n[q3499] r=sin x-x")
r = sp.sin(x) - x
deg, coef = order_and_coeff(r)
print(f"  主部: x^{deg} * {coef}; 同阶 s=3")
rv = sp.asin(x) - x
dv, cv = order_and_coeff(rv)
print(f"  变式 arcsin x-x 主部: x^{dv} * {cv}; s=3")

# ---- q3500: 立方根 ----
print("\n[q3500] s=∛(1+x)-1-x/3")
s = sp.root(1 + x, 3) - 1 - x/3
deg, coef = order_and_coeff(s)
print(f"  主部: x^{deg} * {coef}; s=o(x^t) => t<2, 整数取 1")
sv = sp.root(1 + x**2, 3) - 1 - x**2/3
dv, cv = order_and_coeff(sv)
print(f"  变式主部: x^{dv} * {cv}; 阶数 4")

# ---- q3501: cos x -1 + x^2/2 ----
print("\n[q3501] u=cos x-1+x^2/2")
u = sp.cos(x) - 1 + x**2/2
deg, coef = order_and_coeff(u)
print(f"  主部: x^{deg} * {coef}; 同阶 v=4")
uv = sp.cos(x) - 1
dv, cv = order_and_coeff(uv)
print(f"  变式 cos x-1 主部: x^{dv} * {cv}; v=2")

# ---- q3502: arctan x - x ----
print("\n[q3502] v=arctan x-x")
v = sp.atan(x) - x
deg, coef = order_and_coeff(v)
print(f"  主部: x^{deg} * {coef}; v=o(x^w) => w<3, 最大 w=2")
print("  变式 (arctan x-x)/x^3 ->", sp.limit(v/x**3, x, 0))

# ---- q3503: sinh x - x ----
print("\n[q3503] w=sinh x-x")
w = sp.sinh(x) - x
deg, coef = order_and_coeff(w)
print(f"  主部: x^{deg} * {coef}; 同阶 z=3")
wv = sp.cosh(x) - 1
dv, cv = order_and_coeff(wv)
print(f"  变式 cosh x-1 主部: x^{dv} * {cv}; z=2")

# ---- q3504: (1/x)∫(e^{t^2}-1)dt ----
print("\n[q3504] f=(1/x)∫0^x(e^{t^2}-1)dt")
f4 = p / x
deg, coef = order_and_coeff(f4)
print(f"  主部: x^{deg} * {coef}; f=o(x^n) => n<2, 整数 n=1")
f4v = pv / x
dv, cv = order_and_coeff(f4v)
print(f"  变式(对数)主部: x^{dv} * {cv}; n=1")

# ---- q3505: (tan x-x)/x^3 ----
print("\n[q3505] g=(tan x-x)/x^3")
g5 = sp.tan(x) - x
print("  极限 A =", sp.limit(g5/x**3, x, 0))
print("  变式 (tan 2x-2x)/x^3 ->", sp.limit((sp.tan(2*x)-2*x)/x**3, x, 0))

# ---- q3506: (ln(1+x)-x)/x^2 ----
print("\n[q3506] h=(ln(1+x)-x)/x^2")
print("  极限 B =", sp.limit(q/x**2, x, 0))
print("  变式 [ln(1+x)-x+x^2/2]/x^3 ->", sp.limit(qv/x**3, x, 0))

# ---- q3507: ∫ln(1+t^2)dt ----
print("\n[q3507] p=∫0^x ln(1+t^2)dt")
deg, coef = order_and_coeff(pv)
print(f"  主部: x^{deg} * {coef}; 同阶 q=3")
p7v = sp.integrate(sp.log(1 + t), (t, 0, x))
dv, cv = order_and_coeff(p7v)
print(f"  变式 ∫ln(1+t)dt 主部: x^{dv} * {cv}; q=2")

# ---- q3508: (sin x-x)/x^3 ----
print("\n[q3508] q=(sin x-x)/x^3")
print("  极限 C =", sp.limit(r/x**3, x, 0))
print("  变式 (arcsin x-x)/x^3 ->", sp.limit(rv/x**3, x, 0))

# ---- q3509: sqrt(1+x)-1-x/2 ----
print("\n[q3509] r=√(1+x)-1-x/2")
r9 = sp.sqrt(1 + x) - 1 - x/2
deg, coef = order_and_coeff(r9)
print(f"  主部: x^{deg} * {coef}; r=o(x^s) => s<2, 整数取 1")
r9v = sp.sqrt(1 + x**2) - 1 - x**2/2
dv, cv = order_and_coeff(r9v)
print(f"  变式主部: x^{dv} * {cv}; 阶数 4")

# ---- q3510: (cos x-1)/x^2 ----
print("\n[q3510] s=(cos x-1)/x^2")
print("  极限 D =", sp.limit(uv/x**2, x, 0))
print("  变式 (1-cos x)/x^2 ->", sp.limit(-uv/x**2, x, 0))

# ---- q3511: ∫(cos t-1)dt ----
print("\n[q3511] t=∫0^x(cos t-1)dt")
t11 = sp.integrate(sp.cos(t) - 1, (t, 0, x))
deg, coef = order_and_coeff(t11)
print(f"  主部: x^{deg} * {coef}; 同阶 u=3")
t11v = sp.integrate(1 - sp.cos(t), (t, 0, x))
dv, cv = order_and_coeff(t11v)
print(f"  变式 ∫(1-cos t)dt 主部: x^{dv} * {cv}; u=3")

# ---- q3512: (arctan x-x)/x^3 ----
print("\n[q3512] u=(arctan x-x)/x^3")
print("  极限 E =", sp.limit(v/x**3, x, 0))
v12 = sp.atan(x) - x + x**3/3
print("  变式 [arctan x-x+x^3/3]/x^5 ->", sp.limit(v12/x**5, x, 0))

# ---- q3513: e^x-1-x ----
print("\n[q3513] v=e^x-1-x")
v13 = sp.exp(x) - 1 - x
deg, coef = order_and_coeff(v13)
print(f"  主部: x^{deg} * {coef}; v=o(x^w) => w<2, 最大 w=1")
v13v = sp.exp(x) - 1 - x - x**2/2
dv, cv = order_and_coeff(v13v)
print(f"  变式主部: x^{dv} * {cv}; w<3, 最大 w=2")

# ---- q3514: (sin x - x cos x)/x^3 ----
print("\n[q3514] f=(sin x-x cos x)/x^3")
f14 = sp.sin(x) - x*sp.cos(x)
print("  极限 F =", sp.limit(f14/x**3, x, 0))
f14v = sp.sin(x**2) - x**2*sp.cos(x**2)
print("  变式 [sin(x^2)-x^2 cos(x^2)]/x^6 ->", sp.limit(f14v/x**6, x, 0))

# ---- q3515: ∫sin t/t dt - x ----
print("\n[q3515] g=∫0^x sin t/t dt - x")
g15 = sp.integrate(sp.sin(t)/t, (t, 0, x)) - x
deg, coef = order_and_coeff(g15)
print(f"  主部: x^{deg} * {coef}; g=o(x^n) => n<3, 整数 n=2")
g15v = sp.integrate(sp.tan(t)/t, (t, 0, x)) - x
dv, cv = order_and_coeff(g15v)
print(f"  变式 ∫tan t/t dt-x 主部: x^{dv} * {cv}; n=2")

# ---- q3516: (tan x-sin x)/x^3 ----
print("\n[q3516] h=(tan x-sin x)/x^3")
print("  极限 G =", sp.limit(g/x**3, x, 0))
print("  变式 /[x(1-cos x)] ->", sp.limit(g/(x*(1-sp.cos(x))), x, 0))

# ---- q3517: ln(cos x) ----
print("\n[q3517] p=ln(cos x)")
p17 = sp.log(sp.cos(x))
deg, coef = order_and_coeff(p17)
print(f"  主部: x^{deg} * {coef}; 同阶 q=2")
p17v = -p17
dv, cv = order_and_coeff(p17v)
print(f"  变式 ln(sec x) 主部: x^{dv} * {cv}; q=2")

# ---- q3518: [ln(1+x)-x+x^2/2]/x^3 ----
print("\n[q3518] q=[ln(1+x)-x+x^2/2]/x^3")
print("  极限 H =", sp.limit(qv/x**3, x, 0))
print("  变式 (ln(1+x)-x)/x^2 ->", sp.limit(q/x**2, x, 0))

# ---- q3519: ∫ln(1+t)/t dt ----
print("\n[q3519] r=∫0^x ln(1+t)/t dt")
r19 = sp.integrate(sp.log(1 + t)/t, (t, 0, x))
deg, coef = order_and_coeff(r19)
print(f"  主部: x^{deg} * {coef}; 同阶 s=1")
r19v = sp.integrate(sp.log(1 + t**2)/t, (t, 0, x))
dv, cv = order_and_coeff(r19v)
print(f"  变式 ∫ln(1+t^2)/t dt 主部: x^{dv} * {cv}; s=2")

# ---- q3520: [e^x-1-x-x^2/2]/x^3 ----
print("\n[q3520] s=[e^x-1-x-x^2/2]/x^3")
print("  极限 I =", sp.limit(v13v/x**3, x, 0))
print("  变式 (e^x-1-x)/x^2 ->", sp.limit(v13/x**2, x, 0))

# ---- q3521: sqrt(cos x)-1 ----
print("\n[q3521] t=√cos x-1")
t21 = sp.sqrt(sp.cos(x)) - 1
deg, coef = order_and_coeff(t21)
print(f"  主部: x^{deg} * {coef}; 同阶 u=2")
t21v = sp.root(sp.cos(x), 3) - 1
dv, cv = order_and_coeff(t21v)
print(f"  变式 ∛cos x-1 主部: x^{dv} * {cv}; u=2")

# ---- q3522: (arcsin x-x)/x^3 ----
print("\n[q3522] u=(arcsin x-x)/x^3")
print("  极限 J =", sp.limit(rv/x**3, x, 0))
print("  变式 (x-arcsin x)/x^3 ->", sp.limit(-rv/x**3, x, 0))

# ---- q3523: sin(x^2)-x^2 ----
print("\n[q3523] v=sin(x^2)-x^2")
v23 = sp.sin(x**2) - x**2
deg, coef = order_and_coeff(v23)
print(f"  主部: x^{deg} * {coef}; v=o(x^w) => w<6, 最大 w=5")
v23v = sp.sin(x**3) - x**3
dv, cv = order_and_coeff(v23v)
print(f"  变式 sin(x^3)-x^3 主部: x^{dv} * {cv}; w<9, 最大 w=8")

# ---- q3524: [sin(tan x)-tan(sin x)]/x^7  ★争议题 ----
print("\n[q3524] f=[sin(tan x)-tan(sin x)]/x^7  ★")
f24 = sp.sin(sp.tan(x)) - sp.tan(sp.sin(x))
ser = sp.series(f24, x, 0, 9).removeO()
print("  符号展开:", sp.expand(ser))
deg, coef = order_and_coeff(f24)
print(f"  主部: x^{deg} * {coef}")
print("  极限 K =", sp.limit(f24/x**7, x, 0))
# 数值采样双侧
for d in (0.15, 0.1, 0.05):
    z = mp.mpf(d)
    val = (mp.sin(mp.tan(z)) - mp.tan(mp.sin(z))) / z**7
    print(f"    x={d}: 比值={float(val):.6f}")
# 反向: tan(sin x)-sin(tan x)
f24r = sp.tan(sp.sin(x)) - sp.sin(sp.tan(x))
print("  反向 [tan(sin x)-sin(tan x)]/x^7 =", sp.limit(f24r/x**7, x, 0))

# ---- q3525: ∫sin(t^2)/t dt ----
print("\n[q3525] g=∫0^x sin(t^2)/t dt")
g25 = sp.integrate(sp.sin(t**2)/t, (t, 0, x))
deg, coef = order_and_coeff(g25)
print(f"  主部: x^{deg} * {coef}; 同阶 n=2")
g25v = sp.integrate(sp.sin(t**3)/t, (t, 0, x))
dv, cv = order_and_coeff(g25v)
print(f"  变式 ∫sin(t^3)/t dt 主部: x^{dv} * {cv}; n=3")

# ---- q3526: [ln(1+sin x)-x]/x^2 ----
print("\n[q3526] h=[ln(1+sin x)-x]/x^2")
h26 = sp.log(1 + sp.sin(x)) - x
print("  极限 L =", sp.limit(h26/x**2, x, 0))
h26v = sp.log(1 + sp.tan(x)) - x
print("  变式 [ln(1+tan x)-x]/x^2 ->", sp.limit(h26v/x**2, x, 0))

# ---- q3527: e^{sin x}-1-x ----
print("\n[q3527] p=e^{sin x}-1-x")
p27 = sp.exp(sp.sin(x)) - 1 - x
deg, coef = order_and_coeff(p27)
print(f"  主部: x^{deg} * {coef}; p=o(x^q) => q<2, 整数取 1")
p27v = sp.exp(sp.tan(x)) - 1 - x
dv, cv = order_and_coeff(p27v)
print(f"  变式 e^{{tan x}}-1-x 主部: x^{dv} * {cv}; q=1")

# ---- q3528: [arctan(sin x)-x]/x^3 ----
print("\n[q3528] q=[arctan(sin x)-x]/x^3")
q28 = sp.atan(sp.sin(x)) - x
print("  极限 M =", sp.limit(q28/x**3, x, 0))
q28v = sp.asin(sp.tan(x)) - x
print("  变式 [arcsin(tan x)-x]/x^3 ->", sp.limit(q28v/x**3, x, 0))

# ---- q3529: ln(1+x)-sin x ----
print("\n[q3529] r=ln(1+x)-sin x")
r29 = sp.log(1 + x) - sp.sin(x)
deg, coef = order_and_coeff(r29)
print(f"  主部: x^{deg} * {coef}; 同阶 s=2")
r29v = sp.log(1 + x) - sp.tan(x)
dv, cv = order_and_coeff(r29v)
print(f"  变式 ln(1+x)-tan x 主部: x^{dv} * {cv}; s=2")

# ---- q3530: (sinh x-sin x)/x^3 ----
print("\n[q3530] s=(sinh x-sin x)/x^3")
s30 = sp.sinh(x) - sp.sin(x)
print("  极限 N =", sp.limit(s30/x**3, x, 0))
print("  变式 (cosh x-cos x)/x^2 ->", sp.limit((sp.cosh(x)-sp.cos(x))/x**2, x, 0))

print("\n" + "=" * 70)
print("复算完成")
